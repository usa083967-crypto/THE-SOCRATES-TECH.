import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../lib/AuthContext'
import { useQuery } from '../../lib/hooks'
import { Spinner, Empty, ErrorBox } from '../../components/ui'

const Title = ({ children }) => <h1 className="mb-5 text-2xl font-bold">{children}</h1>

// Teacher record + assigned courses (RLS limits all data to these courses)
function useTeacher() {
  const { user } = useAuth()
  return useQuery(async (db) => {
    const t = await db.from('teachers').select('*, course_teachers(courses(id,title))').eq('profile_id', user.id).maybeSingle()
    return t
  }, [user.id])
}
function Gate({ children }) {
  const t = useTeacher()
  if (t.loading) return <Spinner />
  if (!t.data) return <Empty title="No teacher profile linked" text="Ask the administrator to link your account in Admin > Teachers & Permissions." />
  const courses = t.data.course_teachers.map((x) => x.courses).filter(Boolean)
  return children(t.data, courses)
}

export function Classes() {
  return <Gate>{(t, courses) => (
    <div><Title>My Classes</Title>
      {!courses.length ? <Empty title="No classes assigned yet" /> : <div className="grid gap-4 md:grid-cols-2">{courses.map((c) => <StudentsCard key={c.id} course={c} />)}</div>}
    </div>)}</Gate>
}
function StudentsCard({ course }) {
  const { data, loading } = useQuery((db) => db.from('enrollments').select('student_id, students(full_name,student_code,mobile)').eq('course_id', course.id), [course.id])
  return (
    <div className="card"><h2 className="font-bold">{course.title}</h2>
      {loading ? <Spinner /> : !data?.length ? <p className="mt-2 text-sm text-slate-500">No students enrolled.</p> :
        <ul className="mt-2 divide-y text-sm">{data.map((e) => <li key={e.student_id} className="py-1.5">{e.students?.student_code} · {e.students?.full_name}</li>)}</ul>}
    </div>
  )
}

export function AttendanceTeacher() {
  return <Gate>{(t, courses) => <AttInner t={t} courses={courses} />}</Gate>
}
function AttInner({ t, courses }) {
  const { user } = useAuth()
  const [cid, setCid] = useState('')
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const [marks, setMarks] = useState({})
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')
  const roster = useQuery((db) => (cid ? db.from('enrollments').select('student_id, students(full_name,student_code)').eq('course_id', cid) : Promise.resolve({ data: [] })), [cid])

  if (!t.can_mark_attendance) return <Empty title="Permission needed" text="The administrator has not allowed you to mark attendance." />

  async function save() {
    setErr(''); setMsg('')
    const rows = (roster.data || []).map((e) => ({ student_id: e.student_id, course_id: cid, attendance_date: date, status: marks[e.student_id] || 'present', marked_by: user.id }))
    const { error } = await supabase.from('attendance').upsert(rows, { onConflict: 'student_id,course_id,attendance_date' })
    if (error) setErr(error.message); else setMsg('Attendance saved.')
  }
  return (
    <div><Title>Mark Attendance</Title>
      <div className="mb-4 flex flex-wrap gap-3"><select className="input max-w-xs" value={cid} onChange={(e) => setCid(e.target.value)}><option value="">Select course</option>{courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select>
        <input type="date" className="input max-w-xs" value={date} onChange={(e) => setDate(e.target.value)} /></div>
      {cid && (roster.loading ? <Spinner /> : !roster.data?.length ? <Empty title="No students enrolled in this course" /> : (
        <div className="card"><table className="w-full"><tbody>{roster.data.map((e) => (
          <tr key={e.student_id} className="border-t first:border-0"><td className="td">{e.students?.student_code} · {e.students?.full_name}</td>
            <td className="td"><select className="input max-w-[9rem]" value={marks[e.student_id] || 'present'} onChange={(ev) => setMarks({ ...marks, [e.student_id]: ev.target.value })}>{['present', 'absent', 'late', 'leave'].map((s) => <option key={s}>{s}</option>)}</select></td></tr>))}</tbody></table>
          <ErrorBox message={err} />{msg && <p className="mt-2 text-sm text-green-600">{msg}</p>}<button className="btn-primary mt-4" onClick={save}>Save attendance</button></div>))}
    </div>
  )
}

export function MaterialsTeacher() {
  return <Gate>{(t, courses) => <MatInner t={t} courses={courses} />}</Gate>
}
function MatInner({ t, courses }) {
  const { user } = useAuth()
  const [f, setF] = useState({ kind: 'material', course_id: '', title: '', description: '', due_date: '' })
  const [file, setFile] = useState(null)
  const [err, setErr] = useState('')
  const [msg, setMsg] = useState('')
  if (!t.can_upload_materials) return <Empty title="Permission needed" text="The administrator has not allowed you to upload materials." />

  async function save(e) {
    e.preventDefault(); setErr(''); setMsg('')
    let path = null
    if (file) {
      if (file.size > 20 * 1024 * 1024) return setErr('File must be under 20 MB.')
      path = `${f.course_id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`
      const up = await supabase.storage.from('materials').upload(path, file)
      if (up.error) return setErr(up.error.message)
    } else if (f.kind === 'material') return setErr('Choose a file.')
    const res = f.kind === 'material'
      ? await supabase.from('materials').insert({ course_id: f.course_id, title: f.title, file_path: path, uploaded_by: user.id })
      : await supabase.from('assignments').insert({ course_id: f.course_id, title: f.title, description: f.description, file_path: path, due_date: f.due_date || null, created_by: user.id })
    if (res.error) return setErr(res.error.message)
    setMsg('Uploaded.'); setF({ ...f, title: '', description: '' }); setFile(null)
  }
  return (
    <div className="max-w-xl"><Title>Notes & Assignments</Title>
      <form onSubmit={save} className="card space-y-3">
        <select className="input" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}><option value="material">Notes / study material</option><option value="assignment">Assignment</option></select>
        <select required className="input" value={f.course_id} onChange={(e) => setF({ ...f, course_id: e.target.value })}><option value="">Course *</option>{courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select>
        <input required className="input" placeholder="Title *" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
        {f.kind === 'assignment' && <><textarea className="input" rows={3} placeholder="Instructions" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /><input type="date" className="input" value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} /></>}
        <input type="file" className="input" onChange={(e) => setFile(e.target.files[0])} />
        <ErrorBox message={err} />{msg && <p className="text-sm text-green-600">{msg}</p>}<button className="btn-primary">Upload</button></form>
    </div>
  )
}

export function MarksTeacher() {
  return <Gate>{(t, courses) => <MarksInner t={t} courses={courses} />}</Gate>
}
function MarksInner({ t, courses }) {
  const { user } = useAuth()
  const [f, setF] = useState({ course_id: '', student_id: '', exam_name: '', marks_obtained: '', total_marks: '', grade: '' })
  const [err, setErr] = useState('')
  const [msg, setMsg] = useState('')
  const roster = useQuery((db) => (f.course_id ? db.from('enrollments').select('student_id, students(full_name,student_code)').eq('course_id', f.course_id) : Promise.resolve({ data: [] })), [f.course_id])
  if (!t.can_enter_marks) return <Empty title="Permission needed" text="The administrator has not allowed you to enter marks." />

  async function save(e) {
    e.preventDefault(); setErr(''); setMsg('')
    if (Number(f.marks_obtained) > Number(f.total_marks)) return setErr('Marks obtained cannot exceed total marks.')
    const { error } = await supabase.from('results').insert({ ...f, marks_obtained: Number(f.marks_obtained), total_marks: Number(f.total_marks), entered_by: user.id })
    if (error) return setErr(error.message)
    setMsg('Saved. The administrator publishes results to students.'); setF({ ...f, student_id: '', marks_obtained: '', grade: '' })
  }
  return (
    <div className="max-w-xl"><Title>Enter Marks</Title>
      <form onSubmit={save} className="card space-y-3">
        <select required className="input" value={f.course_id} onChange={(e) => setF({ ...f, course_id: e.target.value, student_id: '' })}><option value="">Course *</option>{courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select>
        <select required className="input" value={f.student_id} onChange={(e) => setF({ ...f, student_id: e.target.value })}><option value="">Student *</option>{(roster.data || []).map((e) => <option key={e.student_id} value={e.student_id}>{e.students?.student_code} - {e.students?.full_name}</option>)}</select>
        <input required className="input" placeholder="Exam name *" value={f.exam_name} onChange={(e) => setF({ ...f, exam_name: e.target.value })} />
        <div className="grid grid-cols-3 gap-2"><input required type="number" className="input" placeholder="Obtained" value={f.marks_obtained} onChange={(e) => setF({ ...f, marks_obtained: e.target.value })} /><input required type="number" className="input" placeholder="Total" value={f.total_marks} onChange={(e) => setF({ ...f, total_marks: e.target.value })} /><input className="input" placeholder="Grade" value={f.grade} onChange={(e) => setF({ ...f, grade: e.target.value })} /></div>
        <ErrorBox message={err} />{msg && <p className="text-sm text-green-600">{msg}</p>}<button className="btn-primary">Save marks</button></form>
    </div>
  )
}

export function TimetableTeacher() {
  return <Gate>{(t) => <TTInner t={t} />}</Gate>
}
function TTInner({ t }) {
  const { data, loading } = useQuery((db) => db.from('timetable').select('*, courses(title)').eq('teacher_id', t.id).order('day_of_week'), [t.id])
  return (
    <div><Title>My Timetable</Title>
      {loading ? <Spinner /> : !data?.length ? <Empty title="No timetable entries yet" /> :
        <div className="card overflow-x-auto"><table className="w-full"><thead><tr><th className="th">Day</th><th className="th">Time</th><th className="th">Course</th><th className="th">Room</th></tr></thead>
          <tbody>{data.map((r) => <tr key={r.id} className="border-t"><td className="td">{r.day_of_week}</td><td className="td">{r.start_time?.slice(0, 5)} - {r.end_time?.slice(0, 5)}</td><td className="td">{r.courses?.title}</td><td className="td">{r.room}</td></tr>)}</tbody></table></div>}
    </div>
  )
}
