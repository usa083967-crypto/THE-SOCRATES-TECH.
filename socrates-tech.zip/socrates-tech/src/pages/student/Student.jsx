import { useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../lib/AuthContext'
import { useQuery } from '../../lib/hooks'
import { Spinner, Empty, ErrorBox, StatusBadge } from '../../components/ui'
import { money } from '../../lib/config'
import { buildVoucher, buildCertificate } from '../../lib/pdf'

const Title = ({ children }) => <h1 className="mb-5 text-2xl font-bold">{children}</h1>

function useStudent() {
  const { user } = useAuth()
  return useQuery((db) => db.from('students').select('*').eq('profile_id', user.id).maybeSingle(), [user?.id])
}

// Wraps pages that need a linked student record.
function NeedStudent({ children }) {
  const s = useStudent()
  if (s.loading) return <Spinner />
  if (s.error) return <ErrorBox message={s.error} />
  if (!s.data) return <NotLinked />
  return children(s.data)
}

function NotLinked() {
  const { user } = useAuth()
  const apps = useQuery((db) => db.from('applications').select('application_code,status,admin_note,created_at').eq('applicant_id', user.id).order('created_at', { ascending: false }), [user.id])
  return (
    <div className="space-y-4">
      <Title>Welcome</Title>
      <div className="card">
        <p className="font-semibold">No student record is linked to your account yet.</p>
        <p className="mt-1 text-sm text-slate-500">A student record (with Student ID) is created when the administration approves your admission. If you applied while logged in, your application is listed below. If you applied before creating this account, contact the institute so they can link it.</p>
        <Link to="/apply" className="btn-gold mt-4">Apply for admission</Link>
      </div>
      {apps.data?.length > 0 && (
        <div className="card"><h2 className="mb-2 font-bold">Your applications</h2>
          {apps.data.map((a) => <div key={a.application_code} className="flex items-center justify-between border-t py-2 text-sm first:border-0"><span className="font-mono">{a.application_code}</span><StatusBadge status={a.status} />{a.admin_note && <span className="text-slate-500">{a.admin_note}</span>}</div>)}
        </div>)}
    </div>
  )
}

export function Overview() {
  return (
    <NeedStudent>{(s) => <OverviewInner s={s} />}</NeedStudent>
  )
}
function OverviewInner({ s }) {
  const enr = useQuery((db) => db.from('enrollments').select('*, courses(title)').eq('student_id', s.id), [s.id])
  const fees = useQuery((db) => db.from('fee_records').select('total_payable,status').eq('student_id', s.id), [s.id])
  const dues = (fees.data || []).filter((f) => f.status === 'unpaid').reduce((a, f) => a + Number(f.total_payable), 0)
  return (
    <div className="space-y-6">
      <Title>My Dashboard</Title>
      <div className="grid gap-4 md:grid-cols-3">
        <div className="card"><p className="text-xs text-slate-500">Student ID</p><p className="font-mono text-xl font-bold">{s.student_code}</p><p className="mt-2 text-sm">Status: <StatusBadge status={s.status} /></p></div>
        <div className="card"><p className="text-xs text-slate-500">Pending dues</p><p className="text-xl font-bold">{money(dues)}</p><Link to="/student/fees" className="text-sm text-royal-500">View fees →</Link></div>
        <div className="card"><p className="text-xs text-slate-500">Enrolled courses</p><p className="text-xl font-bold">{enr.data?.length ?? '...'}</p></div>
      </div>
      <div className="card">
        <h2 className="mb-3 font-bold">Profile</h2>
        <dl className="grid gap-2 text-sm sm:grid-cols-2">
          {[['Name', s.full_name], ["Father's name", s.father_name], ['CNIC / B-Form', s.cnic], ['Mobile', s.mobile], ['Email', s.email], ['City', s.city], ['Address', s.address], ['Qualification', s.qualification]]
            .map(([k, v]) => <div key={k}><dt className="inline font-semibold">{k}: </dt><dd className="inline">{v || '-'}</dd></div>)}
        </dl>
      </div>
      <div className="card"><h2 className="mb-3 font-bold">Enrolled courses</h2>
        {enr.loading ? <Spinner /> : !enr.data?.length ? <Empty title="Not enrolled in any course yet" /> :
          enr.data.map((e) => <div key={e.id} className="flex items-center justify-between border-t py-2 text-sm first:border-0"><span>{e.courses?.title}</span><span className="text-slate-500">{e.progress_percent}% · <StatusBadge status={e.status} /></span></div>)}
      </div>
    </div>
  )
}

export function Fees() {
  return <NeedStudent>{(s) => <FeesInner s={s} />}</NeedStudent>
}
function FeesInner({ s }) {
  const fees = useQuery((db) => db.from('fee_records').select('*, enrollments(courses(title))').eq('student_id', s.id).order('issue_date', { ascending: false }), [s.id])
  const pays = useQuery((db) => db.from('payments').select('*').eq('student_id', s.id).order('paid_on', { ascending: false }), [s.id])
  const pending = (fees.data || []).filter((f) => f.status === 'unpaid')
  const printable = (f) => buildVoucher(f, s, f.enrollments?.courses?.title)
  return (
    <div className="space-y-6">
      <Title>Fees & Vouchers</Title>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="card"><p className="text-xs text-slate-500">Pending dues</p><p className="text-2xl font-bold text-red-600">{money(pending.reduce((a, f) => a + Number(f.total_payable), 0))}</p></div>
        <div className="card"><p className="text-xs text-slate-500">Total paid (verified)</p><p className="text-2xl font-bold text-green-600">{money((pays.data || []).reduce((a, p) => a + Number(p.amount), 0))}</p></div>
      </div>
      <div className="card overflow-x-auto">
        <h2 className="mb-2 font-bold">Vouchers</h2>
        {fees.loading ? <Spinner /> : fees.error ? <ErrorBox message={fees.error} /> : !fees.data?.length ? <Empty title="No fee vouchers yet" text="Vouchers appear here when the administration generates them." /> :
          <table className="w-full"><thead><tr><th className="th">Voucher</th><th className="th">Type</th><th className="th">Month</th><th className="th">Due</th><th className="th">Total</th><th className="th">Status</th><th className="th" /></tr></thead>
            <tbody>{fees.data.map((f) => (
              <tr key={f.id} className="border-t"><td className="td font-mono">{f.voucher_no}</td><td className="td">{f.fee_type}</td><td className="td">{f.fee_month || '-'}</td><td className="td">{f.due_date || '-'}</td>
                <td className="td">{money(f.total_payable)}</td><td className="td"><StatusBadge status={f.status} /></td>
                <td className="td"><button className="btn-outline !px-3 !py-1" onClick={() => printable(f)}>Download PDF</button></td></tr>))}</tbody></table>}
      </div>
      <div className="card overflow-x-auto"><h2 className="mb-2 font-bold">Paid fee history</h2>
        {!pays.data?.length ? <Empty title="No verified payments yet" text="A payment is listed only after the administration verifies it." /> :
          <table className="w-full"><thead><tr><th className="th">Date</th><th className="th">Amount</th><th className="th">Method</th><th className="th">Reference</th></tr></thead>
            <tbody>{pays.data.map((p) => <tr key={p.id} className="border-t"><td className="td">{p.paid_on}</td><td className="td">{money(p.amount)}</td><td className="td">{p.method}</td><td className="td">{p.reference_no}</td></tr>)}</tbody></table>}
      </div>
    </div>
  )
}

export function Attendance() {
  return <NeedStudent>{(s) => <AttInner s={s} />}</NeedStudent>
}
function AttInner({ s }) {
  const { data, loading } = useQuery((db) => db.from('attendance').select('*, courses(title)').eq('student_id', s.id).order('attendance_date', { ascending: false }), [s.id])
  const total = data?.length || 0
  const present = (data || []).filter((a) => a.status === 'present' || a.status === 'late').length
  return (
    <div><Title>Attendance</Title>
      {loading ? <Spinner /> : !total ? <Empty title="No attendance recorded yet" /> : <>
        <p className="mb-4 text-sm">Attendance rate: <b>{Math.round((present / total) * 100)}%</b> ({present} of {total} classes)</p>
        <div className="card overflow-x-auto"><table className="w-full"><thead><tr><th className="th">Date</th><th className="th">Course</th><th className="th">Status</th></tr></thead>
          <tbody>{data.map((a) => <tr key={a.id} className="border-t"><td className="td">{a.attendance_date}</td><td className="td">{a.courses?.title}</td><td className="td capitalize">{a.status}</td></tr>)}</tbody></table></div></>}
    </div>
  )
}

export function Timetable() {
  const { user } = useAuth()
  const { data, loading } = useQuery((db) => db.from('timetable').select('*, courses(title), teachers(full_name)').order('day_of_week'), [user.id])
  return (
    <div><Title>Class Timetable</Title>
      {loading ? <Spinner /> : !data?.length ? <Empty title="No timetable published yet" /> :
        <div className="card overflow-x-auto"><table className="w-full"><thead><tr><th className="th">Day</th><th className="th">Time</th><th className="th">Course</th><th className="th">Teacher</th><th className="th">Room</th></tr></thead>
          <tbody>{data.map((t) => <tr key={t.id} className="border-t"><td className="td">{t.day_of_week}</td><td className="td">{t.start_time?.slice(0, 5)} - {t.end_time?.slice(0, 5)}</td><td className="td">{t.courses?.title}</td><td className="td">{t.teachers?.full_name || '-'}</td><td className="td">{t.room || '-'}</td></tr>)}</tbody></table></div>}
    </div>
  )
}

export function Results() {
  return <NeedStudent>{(s) => <ResultsInner s={s} />}</NeedStudent>
}
function ResultsInner({ s }) {
  const { data, loading } = useQuery((db) => db.from('results').select('*, courses(title)').eq('student_id', s.id).order('created_at', { ascending: false }), [s.id])
  return (
    <div><Title>Examination Results</Title>
      {loading ? <Spinner /> : !data?.length ? <Empty title="No published results yet" /> :
        <div className="card overflow-x-auto"><table className="w-full"><thead><tr><th className="th">Course</th><th className="th">Exam</th><th className="th">Marks</th><th className="th">Grade</th></tr></thead>
          <tbody>{data.map((r) => <tr key={r.id} className="border-t"><td className="td">{r.courses?.title}</td><td className="td">{r.exam_name}</td><td className="td">{r.marks_obtained} / {r.total_marks}</td><td className="td">{r.grade || '-'}</td></tr>)}</tbody></table></div>}
    </div>
  )
}

async function openFile(bucket, path) {
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, 120)
  if (error) return alert(error.message)
  window.open(data.signedUrl, '_blank')
}

export function Materials() {
  const { user } = useAuth()
  const { data, loading } = useQuery((db) => db.from('materials').select('*, courses(title)').order('created_at', { ascending: false }), [user.id])
  return (
    <div><Title>Study Materials</Title>
      {loading ? <Spinner /> : !data?.length ? <Empty title="No materials uploaded yet" text="Notes and PDFs from your teachers appear here." /> :
        <div className="space-y-2">{data.map((m) => <div key={m.id} className="card flex items-center justify-between !p-4"><div><p className="font-semibold">{m.title}</p><p className="text-xs text-slate-500">{m.courses?.title}</p></div><button className="btn-primary !px-3 !py-1.5" onClick={() => openFile('materials', m.file_path)}>Download</button></div>)}</div>}
    </div>
  )
}

export function Assignments() {
  return <NeedStudent>{(s) => <AssignInner s={s} />}</NeedStudent>
}
function AssignInner({ s }) {
  const a = useQuery((db) => db.from('assignments').select('*, courses(title)').order('due_date'), [s.id])
  const subs = useQuery((db) => db.from('submissions').select('*').eq('student_id', s.id), [s.id])
  const [busy, setBusy] = useState('')
  const [err, setErr] = useState('')
  const { user } = useAuth()

  async function submit(assignment, file) {
    if (!file) return
    if (file.size > 10 * 1024 * 1024) return setErr('File must be under 10 MB.')
    setBusy(assignment.id); setErr('')
    const path = `${user.id}/${assignment.id}-${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`
    const up = await supabase.storage.from('submissions').upload(path, file)
    if (up.error) { setBusy(''); return setErr(up.error.message) }
    const { error } = await supabase.from('submissions').insert({ assignment_id: assignment.id, student_id: s.id, file_path: path })
    setBusy(''); if (error) setErr(error.message); else subs.reload()
  }

  return (
    <div><Title>Assignments</Title><ErrorBox message={err} />
      {a.loading ? <Spinner /> : !a.data?.length ? <Empty title="No assignments yet" /> :
        <div className="space-y-3">{a.data.map((x) => {
          const sub = subs.data?.find((q) => q.assignment_id === x.id)
          return (
            <div key={x.id} className="card"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="font-semibold">{x.title}</p><p className="text-xs text-slate-500">{x.courses?.title} · Due {x.due_date || 'no date'}</p></div>
              {x.file_path && <button className="btn-outline !px-3 !py-1.5" onClick={() => openFile('materials', x.file_path)}>Download brief</button>}</div>
              <p className="mt-2 text-sm">{x.description}</p>
              <div className="mt-3 text-sm">{sub ? <span>Submitted {new Date(sub.submitted_at).toLocaleDateString()}{sub.marks != null && <b> · Marks: {sub.marks}</b>}</span> :
                <label className="btn-primary cursor-pointer !py-1.5">{busy === x.id ? 'Uploading...' : 'Upload submission'}<input type="file" className="hidden" onChange={(e) => submit(x, e.target.files[0])} /></label>}</div>
            </div>)
        })}</div>}
    </div>
  )
}

// Courses with modules, lessons, progress and quizzes
export function MyCourses() {
  return <NeedStudent>{(s) => <CoursesInner s={s} />}</NeedStudent>
}
function CoursesInner({ s }) {
  const enr = useQuery((db) => db.from('enrollments').select('*, courses(id,title)').eq('student_id', s.id), [s.id])
  const [open, setOpen] = useState(null)
  return (
    <div><Title>My Courses & Lessons</Title>
      {enr.loading ? <Spinner /> : !enr.data?.length ? <Empty title="You are not enrolled in any course yet" /> :
        <div className="space-y-4">{enr.data.map((e) => (
          <div key={e.id} className="card"><div className="flex items-center justify-between"><div><p className="font-bold">{e.courses.title}</p><p className="text-xs text-slate-500">Progress {e.progress_percent}% · <StatusBadge status={e.status} /></p></div>
            <button className="btn-outline !px-3 !py-1.5" onClick={() => setOpen(open === e.id ? null : e.id)}>{open === e.id ? 'Hide' : 'Open'}</button></div>
            {open === e.id && <CourseContent courseId={e.courses.id} student={s} />}</div>))}</div>}
    </div>
  )
}
function CourseContent({ courseId, student }) {
  const mods = useQuery((db) => db.from('modules').select('*, lessons(*)').eq('course_id', courseId).order('position'), [courseId])
  const done = useQuery((db) => db.from('lesson_progress').select('lesson_id').eq('student_id', student.id), [student.id])
  const quizzes = useQuery((db) => db.from('quizzes').select('*, quiz_questions(*)').eq('course_id', courseId), [courseId])
  const [quiz, setQuiz] = useState(null)
  const doneSet = new Set((done.data || []).map((d) => d.lesson_id))

  async function mark(lessonId) {
    await supabase.from('lesson_progress').upsert({ student_id: student.id, lesson_id: lessonId })
    done.reload()
  }
  return (
    <div className="mt-4 space-y-4 border-t pt-4">
      {mods.loading ? <Spinner /> : !mods.data?.length ? <p className="text-sm text-slate-500">No lessons have been added to this course yet.</p> :
        mods.data.map((m) => (
          <div key={m.id}><p className="font-semibold">{m.title}</p>
            <ul className="mt-1 space-y-2">{(m.lessons || []).sort((a, b) => a.position - b.position).map((l) => (
              <li key={l.id} className="rounded-lg bg-slate-50 p-3 text-sm dark:bg-white/5"><div className="flex items-center justify-between"><span>{l.title}</span>
                {doneSet.has(l.id) ? <span className="text-green-600">Completed</span> : <button className="text-royal-500" onClick={() => mark(l.id)}>Mark complete</button>}</div>
                {l.content && <p className="mt-1 whitespace-pre-line text-slate-600 dark:text-slate-300">{l.content}</p>}
                {l.video_url && <a href={l.video_url} target="_blank" rel="noreferrer" className="mt-1 inline-block text-royal-500">Watch lecture →</a>}</li>))}</ul></div>))}
      {quizzes.data?.filter((q) => q.is_published).map((q) => <button key={q.id} className="btn-primary !py-1.5" onClick={() => setQuiz(q)}>Take quiz: {q.title}</button>)}
      {quiz && <Quiz quiz={quiz} student={student} onClose={() => setQuiz(null)} />}
    </div>
  )
}
function Quiz({ quiz, student, onClose }) {
  const [ans, setAns] = useState({})
  const [score, setScore] = useState(null)
  async function finish() {
    const sc = quiz.quiz_questions.filter((q) => ans[q.id] === q.correct_index).length
    setScore(sc)
    await supabase.from('quiz_attempts').insert({ quiz_id: quiz.id, student_id: student.id, score: sc, total: quiz.quiz_questions.length })
  }
  return (
    <div className="rounded-xl border p-4"><p className="font-bold">{quiz.title}</p>
      {quiz.quiz_questions.map((q, i) => (
        <div key={q.id} className="mt-3"><p className="text-sm font-medium">{i + 1}. {q.question}</p>
          {q.options.map((o, j) => <label key={j} className="mt-1 flex items-center gap-2 text-sm"><input type="radio" name={q.id} disabled={score != null} onChange={() => setAns({ ...ans, [q.id]: j })} /> {o}</label>)}</div>))}
      <div className="mt-4 flex items-center gap-3">{score == null ? <button className="btn-primary !py-1.5" onClick={finish}>Submit</button> : <b>Score: {score} / {quiz.quiz_questions.length}</b>}
        <button className="btn-outline !py-1.5" onClick={onClose}>Close</button></div></div>
  )
}

export function Certificates() {
  return <NeedStudent>{(s) => <CertInner s={s} />}</NeedStudent>
}
function CertInner({ s }) {
  const { data, loading } = useQuery((db) => db.from('certificates').select('*').eq('student_id', s.id).eq('is_revoked', false), [s.id])
  return (
    <div><Title>Certificates</Title>
      {loading ? <Spinner /> : !data?.length ? <Empty title="No certificates issued yet" text="Certificates are issued after the administration confirms course completion." /> :
        <div className="space-y-3">{data.map((c) => <div key={c.id} className="card flex items-center justify-between"><div><p className="font-semibold">{c.course_title}</p><p className="text-xs text-slate-500">{c.certificate_no} · {c.completion_date}</p></div><button className="btn-primary !py-1.5" onClick={() => buildCertificate(c)}>Download PDF</button></div>)}</div>}
    </div>
  )
}

export function Notifications() {
  const { user } = useAuth()
  const n = useQuery((db) => db.from('notifications').select('*').order('created_at', { ascending: false }).limit(50), [user.id])
  const a = useQuery((db) => db.from('announcements').select('*').order('created_at', { ascending: false }).limit(20), [user.id])
  async function read(id) { await supabase.from('notifications').update({ is_read: true }).eq('id', id); n.reload() }
  return (
    <div className="space-y-6"><Title>Notifications</Title>
      {n.loading ? <Spinner /> : !n.data?.length ? <Empty title="No notifications" /> :
        <div className="space-y-2">{n.data.map((x) => <div key={x.id} className={`card flex items-start justify-between !p-4 ${x.is_read ? 'opacity-60' : ''}`}><div><p className="font-semibold">{x.title}</p><p className="text-sm">{x.body}</p><p className="text-xs text-slate-500">{new Date(x.created_at).toLocaleString()}</p></div>
          {!x.is_read && x.user_id && <button className="text-xs text-royal-500" onClick={() => read(x.id)}>Mark read</button>}</div>)}</div>}
      <div><h2 className="mb-2 text-lg font-bold">Announcements</h2>
        {!a.data?.length ? <Empty title="No announcements" /> : a.data.map((x) => <div key={x.id} className="card mb-2 !p-4"><p className="font-semibold">{x.title}</p><p className="text-sm">{x.body}</p></div>)}</div>
    </div>
  )
}

export function Support() {
  return (
    <div><Title>Support & Complaints</Title>
      <div className="card"><p className="text-sm">Send a support request or complaint to the administration. You can track replies by phone or email.</p>
        <div className="mt-4 flex gap-3"><Link to="/contact?kind=support" className="btn-primary">Support request</Link><Link to="/contact?kind=complaint" className="btn-outline">Submit complaint</Link></div></div>
    </div>
  )
}

export function ChangePassword() {
  const [pw, setPw] = useState('')
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')
  async function submit(e) {
    e.preventDefault(); setErr(''); setMsg('')
    if (pw.length < 8) return setErr('Password must be at least 8 characters.')
    const { error } = await supabase.auth.updateUser({ password: pw })
    if (error) setErr(error.message); else { setMsg('Password updated.'); setPw('') }
  }
  return (
    <div className="max-w-md"><Title>Change Password</Title>
      <form onSubmit={submit} className="card space-y-4"><div><label className="label">New password</label><input type="password" className="input" value={pw} onChange={(e) => setPw(e.target.value)} required /></div>
        <ErrorBox message={err} />{msg && <p className="text-sm text-green-600">{msg}</p>}<button className="btn-primary">Update password</button></form>
    </div>
  )
}
