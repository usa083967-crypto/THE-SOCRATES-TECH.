import { useState, useMemo } from 'react'
import { useQuery } from '../../lib/hooks'
import { PageHeader, Spinner, Empty, ErrorBox } from '../../components/ui'
import CourseCard from '../../components/CourseCard'

// filter: undefined = all, or { type, mode }
export default function Courses({ title = 'Our Courses', subtitle = 'Choose a course and apply online.', type, mode }) {
  const [q, setQ] = useState('')
  const [cat, setCat] = useState('all')
  const { data, loading, error } = useQuery((db) => {
    let query = db.from('courses').select('*').eq('is_active', true).order('title')
    if (type) query = query.eq('course_type', type)
    if (mode) query = query.in('mode', [mode, 'both'])
    return query
  }, [type, mode])

  const cats = useMemo(() => ['all', ...new Set((data || []).map((c) => c.category))], [data])
  const list = (data || []).filter((c) => (cat === 'all' || c.category === cat) && c.title.toLowerCase().includes(q.toLowerCase()))

  return (
    <>
      <PageHeader title={title} subtitle={subtitle} />
      <div className="mx-auto max-w-6xl px-4 py-10">
        <div className="mb-6 flex flex-col gap-3 sm:flex-row">
          <input className="input sm:max-w-xs" placeholder="Search courses..." value={q} onChange={(e) => setQ(e.target.value)} />
          <select className="input sm:max-w-xs" value={cat} onChange={(e) => setCat(e.target.value)}>
            {cats.map((c) => <option key={c} value={c}>{c === 'all' ? 'All categories' : c}</option>)}
          </select>
        </div>
        {loading ? <Spinner /> : error ? <ErrorBox message={error} /> : !list.length ? (
          <Empty title={type === 'government' ? 'No verified government programs at the moment' : 'No courses found'}
            text={type === 'government' ? 'Government-sponsored programs are listed here only after their sponsorship, eligibility and affiliation have been verified.' : 'Try a different search.'} />
        ) : <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{list.map((c) => <CourseCard key={c.id} c={c} />)}</div>}
      </div>
    </>
  )
}
