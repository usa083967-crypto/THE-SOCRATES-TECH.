import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { supabase, isConfigured } from '../../lib/supabase'
import { Logo, ErrorBox } from '../../components/ui'

function Shell({ title, children, footer }) {
  return (
    <div className="flex min-h-[80vh] items-center justify-center bg-slate-50 px-4 py-10 dark:bg-navy-950">
      <div className="w-full max-w-md">
        <div className="mb-6 flex justify-center"><Link to="/"><Logo /></Link></div>
        <div className="card"><h1 className="mb-5 text-2xl font-bold">{title}</h1>{children}</div>
        <div className="mt-4 text-center text-sm">{footer}</div>
      </div>
    </div>
  )
}

function Social() {
  async function go(provider) {
    const { error } = await supabase.auth.signInWithOAuth({ provider, options: { redirectTo: window.location.origin + '/student' } })
    if (error) alert(`${provider} sign-in is not enabled yet: ${error.message}\n\nFollow the OAuth steps in README.md.`)
  }
  return (
    <div className="mt-4 space-y-2">
      <div className="text-center text-xs text-slate-500">or</div>
      <button type="button" className="btn-outline w-full" onClick={() => go('google')}>Continue with Google</button>
      <button type="button" className="btn-outline w-full" onClick={() => go('facebook')}>Continue with Facebook</button>
      <p className="text-center text-xs text-slate-500">These work only after Google/Facebook are configured in Supabase (see README).</p>
    </div>
  )
}

// kind: 'student' | 'teacher' | 'admin'
export function Login({ kind = 'student' }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const nav = useNavigate()
  const loc = useLocation()

  async function submit(e) {
    e.preventDefault(); setErr('')
    if (!isConfigured) return setErr('The database is not configured yet. See README.md.')
    setBusy(true)
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) { setBusy(false); return setErr(error.message === 'Email not confirmed' ? 'Please verify your email first. Check your inbox for the verification link.' : error.message) }
    const { data: p } = await supabase.from('profiles').select('role,is_active').eq('id', data.user.id).single()
    setBusy(false)
    if (!p?.is_active) { await supabase.auth.signOut(); return setErr('This account is disabled. Please contact the institute.') }
    if (kind !== p.role) {
      await supabase.auth.signOut()
      return setErr(`This account is not a ${kind} account. Use the correct login page.`)
    }
    nav(loc.state?.from || (kind === 'admin' ? '/admin' : kind === 'teacher' ? '/teacher' : '/student'), { replace: true })
  }

  const title = kind === 'admin' ? 'Admin Login' : kind === 'teacher' ? 'Teacher Login' : 'Student Login'
  return (
    <Shell title={title} footer={kind === 'student' && <>New student? <Link to="/signup" className="font-semibold text-royal-500">Create an account</Link></>}>
      <form onSubmit={submit} className="space-y-4">
        <div><label className="label">Email</label><input type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div><label className="label">Password</label><input type="password" required className="input" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        <ErrorBox message={err} />
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Signing in...' : 'Login'}</button>
        <div className="text-right text-sm"><Link to="/forgot-password" className="text-royal-500">Forgot password?</Link></div>
      </form>
      {kind === 'student' && <Social />}
    </Shell>
  )
}

export function Signup() {
  const [f, setF] = useState({ full_name: '', email: '', password: '' })
  const [err, setErr] = useState('')
  const [done, setDone] = useState(false)
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault(); setErr('')
    if (!isConfigured) return setErr('The database is not configured yet. See README.md.')
    if (f.password.length < 8) return setErr('Password must be at least 8 characters.')
    setBusy(true)
    const { error } = await supabase.auth.signUp({ email: f.email, password: f.password,
      options: { data: { full_name: f.full_name }, emailRedirectTo: window.location.origin + '/login' } })
    setBusy(false)
    if (error) return setErr(error.message)
    setDone(true)
  }

  if (done) return <Shell title="Check your email"><p className="text-sm">We sent a verification link to <b>{f.email}</b>. Click it, then <Link to="/login" className="text-royal-500">log in</Link>.</p></Shell>
  return (
    <Shell title="Create Student Account" footer={<>Already registered? <Link to="/login" className="font-semibold text-royal-500">Login</Link></>}>
      <form onSubmit={submit} className="space-y-4">
        <div><label className="label">Full name</label><input required className="input" value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></div>
        <div><label className="label">Email</label><input type="email" required className="input" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
        <div><label className="label">Password (min 8 characters)</label><input type="password" required className="input" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></div>
        <ErrorBox message={err} />
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Creating...' : 'Sign up'}</button>
        <p className="text-xs text-slate-500">After approval of your admission, the institute links your account to your student record.</p>
      </form>
      <Social />
    </Shell>
  )
}

export function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')
  async function submit(e) {
    e.preventDefault(); setErr(''); setMsg('')
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin + '/reset-password' })
    if (error) setErr(error.message); else setMsg('If that email is registered, a reset link has been sent.')
  }
  return (
    <Shell title="Forgot Password" footer={<Link to="/login" className="text-royal-500">Back to login</Link>}>
      <form onSubmit={submit} className="space-y-4">
        <div><label className="label">Email</label><input type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <ErrorBox message={err} />{msg && <p className="rounded-lg bg-green-50 p-3 text-sm text-green-800">{msg}</p>}
        <button className="btn-primary w-full">Send reset link</button>
      </form>
    </Shell>
  )
}

export function ResetPassword() {
  const [pw, setPw] = useState('')
  const [err, setErr] = useState('')
  const [ok, setOk] = useState(false)
  async function submit(e) {
    e.preventDefault(); setErr('')
    if (pw.length < 8) return setErr('Password must be at least 8 characters.')
    const { error } = await supabase.auth.updateUser({ password: pw })
    if (error) setErr(error.message); else setOk(true)
  }
  return (
    <Shell title="Reset Password">
      {ok ? <p className="text-sm">Password updated. <Link to="/login" className="text-royal-500">Log in</Link>.</p> :
        <form onSubmit={submit} className="space-y-4">
          <p className="text-sm text-slate-500">Open this page from the link in your reset email.</p>
          <div><label className="label">New password</label><input type="password" required className="input" value={pw} onChange={(e) => setPw(e.target.value)} /></div>
          <ErrorBox message={err} /><button className="btn-primary w-full">Update password</button>
        </form>}
    </Shell>
  )
}
