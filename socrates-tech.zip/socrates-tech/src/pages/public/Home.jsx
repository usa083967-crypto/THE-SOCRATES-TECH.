import { Link } from 'react-router-dom'
import { BookOpen, Monitor, Users, Award, GraduationCap, Wallet, MessageCircle } from 'lucide-react'
import { useQuery } from '../../lib/hooks'
import { INSTITUTE, waLink, money } from '../../lib/config'
import { Spinner, Empty } from '../../components/ui'
import CourseCard from '../../components/CourseCard'

const why = [
  [BookOpen, 'Practical skills', 'Hands-on courses designed around skills that employers and clients ask for.'],
  [Monitor, 'Physical & online', 'Attend on campus in Chunian or learn online, depending on the course.'],
  [Users, 'Guided learning', 'Teachers track attendance, assignments and results in your student portal.'],
  [Award, 'Verifiable certificates', 'Every certificate carries a unique ID that anyone can verify online.'],
  [Wallet, 'Clear fee vouchers', 'Download and print your fee voucher any time from your portal.'],
  [GraduationCap, 'Support program', 'Apply for student support. Approval is reviewed case by case.'],
]

export default function Home() {
  const courses = useQuery((db) => db.from('courses').select('*').eq('is_active', true).order('created_at').limit(6), [])
  const announcements = useQuery((db) => db.from('announcements').select('*').in('audience', ['all', 'public']).order('created_at', { ascending: false }).limit(3), [])
  const testimonials = useQuery((db) => db.from('testimonials').select('*').eq('is_published', true).limit(3), [])
  const faqs = useQuery((db) => db.from('faqs').select('*').eq('is_published', true).order('position').limit(6), [])

  return (
    <>
      <section className="relative overflow-hidden bg-gradient-to-br from-navy-950 via-navy-900 to-navy-700 text-white">
        <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-gold-500/10 blur-3xl" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-4 py-20 md:grid-cols-2">
          <div className="animate-fadeUp">
            <span className="badge bg-gold-500/20 text-gold-400">Admissions Open</span>
            <h1 className="mt-4 text-4xl font-extrabold leading-tight sm:text-5xl">
              Welcome to <span className="text-gold-400">{INSTITUTE.name}</span>
            </h1>
            <p className="mt-4 max-w-xl text-lg text-slate-300">
              Computer, IT and professional skills training in Chunian. Apply online, learn on campus or online, and track your progress in your own student portal.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/apply" className="btn-gold">Apply Now</Link>
              <Link to="/login" className="btn border border-white/30 text-white hover:bg-white/10">Student Portal</Link>
              <a href={waLink()} target="_blank" rel="noreferrer" className="btn bg-green-500 text-white hover:bg-green-600"><MessageCircle size={16} /> WhatsApp</a>
            </div>
          </div>
          <div className="hidden md:block">
            <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=900&q=70" alt="Students learning together"
                 className="rounded-2xl border border-white/10 object-cover shadow-2xl" loading="eager" />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="card"><h2 className="text-2xl font-bold">Our Mission</h2><p className="mt-2 text-slate-600 dark:text-slate-300">To give students in Chunian and nearby areas affordable, practical and career-focused technology education.</p></div>
          <div className="card"><h2 className="text-2xl font-bold">Our Vision</h2><p className="mt-2 text-slate-600 dark:text-slate-300">To become a trusted local centre for digital skills, helping young people earn, grow and compete in the modern economy.</p></div>
        </div>
      </section>

      <section className="bg-slate-50 py-16 dark:bg-navy-900/40">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-3xl font-bold">Why Choose Us?</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {why.map(([Icon, t, d]) => (
              <div key={t} className="card transition hover:-translate-y-1 hover:shadow-lg">
                <Icon className="text-royal-500" /><h3 className="mt-3 text-lg font-bold">{t}</h3><p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{d}</p>
              </div>))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="flex items-end justify-between">
          <h2 className="text-3xl font-bold">Our Courses</h2>
          <Link to="/courses" className="text-sm font-semibold text-royal-500">View all courses →</Link>
        </div>
        <div className="mt-8">
          {courses.loading ? <Spinner /> : courses.error ? <Empty title="Courses unavailable" text={courses.error} /> :
            !courses.data?.length ? <Empty title="Courses will appear here" text="The administrator has not published any courses yet." /> :
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{courses.data.map((c) => <CourseCard key={c.id} c={c} />)}</div>}
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-4">
          {[['/physical-classes', 'Physical Classes'], ['/online-learning', 'Online Courses'], ['/government-programs', 'Government Programs'], ['/private-programs', 'Private Programs']].map(([to, l]) => (
            <Link key={to} to={to} className="btn-outline">{l}</Link>))}
        </div>
      </section>

      <section className="bg-slate-50 py-16 dark:bg-navy-900/40">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 md:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold">Latest Announcements</h2>
            <div className="mt-4 space-y-3">
              {announcements.loading ? <Spinner /> : !announcements.data?.length ? <Empty title="No announcements yet" /> :
                announcements.data.map((a) => <div key={a.id} className="card"><p className="font-semibold">{a.title}</p><p className="text-sm text-slate-500">{a.body}</p></div>)}
            </div>
          </div>
          <div className="card bg-gradient-to-br from-navy-900 to-navy-700 text-white">
            <h2 className="text-2xl font-bold">Admission Open</h2>
            <p className="mt-2 text-slate-300">Submit your online application in a few minutes and track it with your application ID.</p>
            <div className="mt-5 flex flex-wrap gap-3"><Link to="/apply" className="btn-gold">Apply Now</Link><Link to="/application-status" className="btn border border-white/30 hover:bg-white/10">Check Status</Link></div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-3xl font-bold">Student Reviews</h2>
        <div className="mt-6">
          {testimonials.loading ? <Spinner /> : !testimonials.data?.length ? <Empty title="Reviews coming soon" text="Student reviews are published here after approval by the administrator." /> :
            <div className="grid gap-5 md:grid-cols-3">{testimonials.data.map((t) => (
              <figure key={t.id} className="card"><blockquote className="text-slate-600 dark:text-slate-300">"{t.quote}"</blockquote><figcaption className="mt-3 text-sm font-semibold">{t.name}{t.course && <span className="font-normal text-slate-500"> · {t.course}</span>}</figcaption></figure>))}</div>}
        </div>
      </section>

      <section className="bg-slate-50 py-16 dark:bg-navy-900/40">
        <div className="mx-auto max-w-3xl px-4">
          <h2 className="text-3xl font-bold">Frequently Asked Questions</h2>
          <div className="mt-6 space-y-3">
            {(faqs.data || []).map((f) => (
              <details key={f.id} className="card cursor-pointer"><summary className="font-semibold">{f.question}</summary><p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{f.answer}</p></details>))}
          </div>
          <p className="mt-6 text-sm">Questions? Call <a href={`tel:${INSTITUTE.phone}`} className="font-semibold text-royal-500">{INSTITUTE.phone}</a> or <Link to="/contact" className="font-semibold text-royal-500">send us a message</Link>.</p>
        </div>
      </section>
    </>
  )
}

export { money }
