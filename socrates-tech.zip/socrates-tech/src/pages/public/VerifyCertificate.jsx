import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { PageHeader, ErrorBox } from '../../components/ui'

export default function VerifyCertificate() {
  const [sp] = useSearchParams()
  const [code, setCode] = useState(sp.get('id') || '')
  const [res, setRes] = useState(null)
  const [err, setErr] = useState('')

  async function check(e) {
    e?.preventDefault(); setErr(''); setRes(null)
    const { data, error } = await supabase.rpc('verify_certificate', { code })
    if (error) return setErr(error.message)
    if (!data?.length) return setErr('No certificate found with that ID. It may be invalid.')
    setRes(data[0])
  }

  return (
    <>
      <PageHeader title="Verify a Certificate" subtitle="Enter the verification ID or certificate number printed on the certificate." />
      <div className="mx-auto max-w-md px-4 py-10">
        <form onSubmit={check} className="card space-y-4">
          <input className="input" required value={code} onChange={(e) => setCode(e.target.value)} placeholder="Verification ID" />
          <ErrorBox message={err} />
          <button className="btn-primary w-full">Verify</button>
        </form>
        {res && (
          <div className={`card mt-6 ${res.is_revoked ? 'border-red-400' : 'border-green-400'}`}>
            <p className={`font-bold ${res.is_revoked ? 'text-red-600' : 'text-green-600'}`}>{res.is_revoked ? 'This certificate has been revoked' : 'Valid certificate'}</p>
            <dl className="mt-3 space-y-1 text-sm">
              <div><dt className="inline font-semibold">Certificate no: </dt><dd className="inline">{res.certificate_no}</dd></div>
              <div><dt className="inline font-semibold">Student: </dt><dd className="inline">{res.student_name}</dd></div>
              <div><dt className="inline font-semibold">Course: </dt><dd className="inline">{res.course_title}</dd></div>
              <div><dt className="inline font-semibold">Completed on: </dt><dd className="inline">{res.completion_date}</dd></div>
            </dl>
          </div>)}
      </div>
    </>
  )
}
