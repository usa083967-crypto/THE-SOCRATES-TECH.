import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Phone, Mail, MessageCircle, MapPin } from 'lucide-react'
import { supabase, isConfigured } from '../../lib/supabase'
import { useAuth } from '../../lib/AuthContext'
import { INSTITUTE, waLink } from '../../lib/config'
import { PageHeader, ErrorBox } from '../../components/ui'

export default function Contact() {
  const [sp] = useSearchParams()
  const { user } = useAuth()
  const [f, setF] = useState({ kind: sp.get('kind') || 'contact', name: '', email: '', phone: '', subject: '', message: '' })
  const [state, setState] = useState({ busy: false, done: false, err: '' })
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  async function submit(e) {
    e.preventDefault()
    if (!isConfigured) return setState({ busy: false, done: false, err: 'The database is not configured yet. See README.md.' })
    setState({ busy: true, done: false, err: '' })
    const { error } = await supabase.from('contact_messages').insert({ ...f, user_id: user?.id || null })
    setState(error ? { busy: false, done: false, err: error.message } : { busy: false, done: true, err: '' })
    if (!error) setF({ ...f, subject: '', message: '' })
  }

  return (
    <>
      <PageHeader title="Contact Us" subtitle="Send a message, a support request or a complaint. We read every submission." />
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-2">
        <div className="space-y-4">
          <div className="card space-y-3 text-sm">
            <p className="flex gap-2"><MapPin size={18} /> {INSTITUTE.city}</p>
            <a className="flex gap-2" href={`tel:${INSTITUTE.phone}`}><Phone size={18} /> {INSTITUTE.phone}</a>
            <a className="flex gap-2" href={`mailto:${INSTITUTE.email}`}><Mail size={18} /> {INSTITUTE.email}</a>
            <div className="flex flex-wrap gap-2 pt-2">
              <a className="btn-primary" href={`tel:${INSTITUTE.phone}`}>Call</a>
              <a className="btn bg-green-500 text-white hover:bg-green-600" href={waLink()} target="_blank" rel="noreferrer"><MessageCircle size={16} /> WhatsApp</a>
              <a className="btn-outline" href={`mailto:${INSTITUTE.email}`}>Email</a>
            </div>
          </div>
          <iframe title="Map of Chunian" className="h-72 w-full rounded-2xl border-0" loading="lazy"
            src="https://www.google.com/maps?q=Chunian,+Punjab,+Pakistan&output=embed" />
          <p className="text-xs text-slate-500">Tip: once you have the institute's exact address, replace the map link in src/pages/public/Contact.jsx with its Google Maps embed link.</p>
        </div>

        <form onSubmit={submit} className="card space-y-4">
          <div><label className="label">This is a...</label>
            <select className="input" value={f.kind} onChange={set('kind')}><option value="contact">General message</option><option value="support">Student support request</option><option value="complaint">Complaint</option></select></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label">Name *</label><input className="input" required value={f.name} onChange={set('name')} /></div>
            <div><label className="label">Phone</label><input className="input" value={f.phone} onChange={set('phone')} /></div>
          </div>
          <div><label className="label">Email</label><input type="email" className="input" value={f.email} onChange={set('email')} /></div>
          <div><label className="label">Subject</label><input className="input" value={f.subject} onChange={set('subject')} /></div>
          <div><label className="label">Message *</label><textarea className="input" rows={5} required minLength={10} value={f.message} onChange={set('message')} /></div>
          <ErrorBox message={state.err} />
          {state.done && <p className="rounded-lg bg-green-50 p-3 text-sm text-green-800">Thank you. Your message has been received.</p>}
          <button className="btn-primary w-full" disabled={state.busy}>{state.busy ? 'Sending...' : 'Send'}</button>
        </form>
      </div>
    </>
  )
}
