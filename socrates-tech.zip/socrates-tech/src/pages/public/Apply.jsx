import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { supabase, isConfigured } from '../../lib/supabase'
import { useQuery } from '../../lib/hooks'
import { PageHeader, ErrorBox } from '../../components/ui'

const MAX_MB = 5
const OK_TYPES = ['image/jpeg', 'image/png', 'application/pdf']
const blank = { full_name: '', father_name: '', dob: '', gender: '', cnic: '', mobile: '', whatsapp: '', email: '', address: '', city: 'Chunian',
  qualification: '', course_id: '', course_type: 'private', learning_mode: 'physical' }

const validCnic = (v) => /^\d{5}-?\d{7}-?\d$/.test(v.trim()) || /^\d{13}$/.test(v.trim())
const validPhone = (v) => /^(\+92|0)?3\d{9}$/.test(v.replace(/[\s-]/g, ''))

export default function Apply() {
  const [sp] = useSearchParams()
  const [f, setF] = useState({ ...blank, course_id: sp.get('course') || '' })
  const [files, setFiles] = useState({})
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [code, setCode] = useState('')
  const courses = useQuery((db) => db.from('courses').select('id,title,course_type,mode').eq('is_active', true).order('title'), [])

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const setFile = (k) => (e) => setFiles({ ...files, [k]: e.target.files[0] })

  async function upload(folder, name, file) {
    if (!file) return null
    const ext = file.name.split('.').pop().toLowerCase().replace(/[^a-z0-9]/g, '')
    const path = `${folder}/${name}.${ext}`
    const { error } = await supabase.storage.from('applications').upload(path, file, { contentType: file.type })
    if (error) throw new Error(`Upload failed (${name}): ${error.message}`)
    return path
  }

  async function submit(e) {
    e.preventDefault()
    setErr('')
    if (!isConfigured) return setErr('The database is not configured yet. See README.md.')
    if (!validCnic(f.cnic)) return setErr('Enter a valid 13-digit CNIC / B-Form number.')
    if (!validPhone(f.mobile)) return setErr('Enter a valid Pakistani mobile number, e.g. 03001234567.')
    if (f.whatsapp && !validPhone(f.whatsapp)) return setErr('WhatsApp number is not valid.')
    if (!f.course_id) return setErr('Please select a course.')
    for (const [k, file] of Object.entries(files)) {
      if (!file) continue
      if (!OK_TYPES.includes(file.type)) return setErr(`${k}: only JPG, PNG or PDF files are allowed.`)
      if (file.size > MAX_MB * 1024 * 1024) return setErr(`${k}: file must be smaller than ${MAX_MB} MB.`)
    }
    setBusy(true)
    try {
      const folder = crypto.randomUUID()
      const photo_path = await upload(folder, 'photo', files.photo)
      const cnic_doc_path = await upload(folder, 'cnic', files.cnic)
      const education_doc_path = await upload(folder, 'education', files.education)
      const { data, error } = await supabase.rpc('submit_application', { p: { ...f, photo_path, cnic_doc_path, education_doc_path } })
      if (error) throw error
      setCode(data)
    } catch (ex) {
      setErr(ex.message || 'Something went wrong. Please try again.')
    } finally { setBusy(false) }
  }

  if (code) {
    return (
      <>
        <PageHeader title="Application received" />
        <div className="mx-auto max-w-xl px-4 py-12">
          <div className="card text-center">
            <p className="text-sm text-slate-500">Your application ID</p>
            <p className="my-2 font-mono text-3xl font-bold text-royal-600">{code}</p>
            <p className="text-sm">Save this ID. Your application is <b>pending review</b>. You can check its status any time using this ID and your CNIC number.</p>
            <div className="mt-6 flex justify-center gap-3">
              <Link to="/application-status" className="btn-primary">Check status</Link>
              <button className="btn-outline" onClick={() => window.print()}>Print</button>
            </div>
          </div>
        </div>
      </>
    )
  }

  const T = ({ k, label, type = 'text', req = true, ...rest }) => (
    <div><label className="label">{label}{req && ' *'}</label><input className="input" type={type} required={req} value={f[k]} onChange={set(k)} {...rest} /></div>
  )

  return (
    <>
      <PageHeader title="Online Admission Application" subtitle="Fill in the form carefully. Fields marked * are required." />
      <form onSubmit={submit} className="mx-auto max-w-3xl space-y-6 px-4 py-10">
        <div className="card grid gap-4 sm:grid-cols-2">
          <T k="full_name" label="Student full name" />
          <T k="father_name" label="Father's name" />
          <T k="dob" label="Date of birth" type="date" />
          <div><label className="label">Gender *</label>
            <select className="input" required value={f.gender} onChange={set('gender')}><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></div>
          <T k="cnic" label="CNIC / B-Form number" placeholder="35xxx-xxxxxxx-x" />
          <T k="mobile" label="Mobile number" type="tel" placeholder="03001234567" />
          <T k="whatsapp" label="WhatsApp number" type="tel" req={false} />
          <T k="email" label="Email address" type="email" req={false} />
          <div className="sm:col-span-2"><T k="address" label="Complete address" /></div>
          <T k="city" label="City" />
          <T k="qualification" label="Educational qualification" placeholder="e.g. Matric, Intermediate" />
        </div>

        <div className="card grid gap-4 sm:grid-cols-3">
          <div className="sm:col-span-3"><label className="label">Selected course *</label>
            <select className="input" required value={f.course_id} onChange={(e) => {
              const c = courses.data?.find((x) => x.id === e.target.value)
              setF({ ...f, course_id: e.target.value, course_type: c?.course_type || 'private' })
            }}>
              <option value="">Select a course</option>
              {(courses.data || []).map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
            </select></div>
          <div><label className="label">Course type</label><input className="input" readOnly value={f.course_type} /></div>
          <div className="sm:col-span-2"><label className="label">Learning preference *</label>
            <select className="input" value={f.learning_mode} onChange={set('learning_mode')}><option value="physical">Physical (on campus)</option><option value="online">Online</option></select></div>
        </div>

        <div className="card space-y-4">
          <p className="text-sm text-slate-500">Allowed: JPG, PNG or PDF, up to {MAX_MB} MB each. Documents are stored privately and seen only by the administration.</p>
          {[['photo', 'Profile picture'], ['cnic', 'CNIC / B-Form document'], ['education', 'Previous educational document']].map(([k, l]) => (
            <div key={k}><label className="label">{l}</label><input className="input" type="file" accept=".jpg,.jpeg,.png,.pdf" onChange={setFile(k)} /></div>))}
        </div>

        <ErrorBox message={err} />
        <button className="btn-gold w-full" disabled={busy}>{busy ? 'Submitting...' : 'Submit application'}</button>
      </form>
    </>
  )
}
