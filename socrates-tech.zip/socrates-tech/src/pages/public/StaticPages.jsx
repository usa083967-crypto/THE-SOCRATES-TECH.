import { Link } from 'react-router-dom'
import { INSTITUTE } from '../../lib/config'
import { useQuery } from '../../lib/hooks'
import { PageHeader, Spinner, Empty } from '../../components/ui'
import Courses from './Courses'

function Doc({ title, subtitle, children }) {
  return (
    <>
      <PageHeader title={title} subtitle={subtitle} />
      <div className="mx-auto max-w-3xl space-y-4 px-4 py-10 leading-relaxed text-slate-700 dark:text-slate-300">{children}</div>
    </>
  )
}
const H = ({ children }) => <h2 className="pt-2 text-xl font-bold text-navy-900 dark:text-white">{children}</h2>

export const About = () => (
  <Doc title="About Us" subtitle={`${INSTITUTE.name}, ${INSTITUTE.city}`}>
    <p>{INSTITUTE.name} is a computer, IT and professional skills institute in Chunian, Punjab. We offer practical courses for students, job seekers, freelancers and professionals.</p>
    <H>What we do</H>
    <p>We teach in-demand skills through physical classes and online learning, and give every student a personal portal to follow admission, fees, attendance, results and certificates.</p>
    <p className="text-sm text-slate-500">Administrators: you can replace this text with your institute's own story, founding year and achievements. Please add only facts you can support.</p>
  </Doc>
)

export const Admissions = () => (
  <Doc title="Admissions" subtitle="How to join">
    <ol className="list-decimal space-y-2 pl-5">
      <li>Choose a course from the <Link className="text-royal-500" to="/courses">course list</Link>.</li>
      <li>Fill in the <Link className="text-royal-500" to="/apply">online application form</Link> and upload your documents.</li>
      <li>Save your application ID. The administration reviews your application and may approve it, reject it or ask for corrections.</li>
      <li>Once approved, log in to the <Link className="text-royal-500" to="/login">Student Portal</Link> to see your fee voucher and class details.</li>
    </ol>
    <div className="flex gap-3 pt-2"><Link to="/apply" className="btn-gold">Apply Now</Link><Link to="/application-status" className="btn-outline">Check status</Link></div>
  </Doc>
)

export const PhysicalClasses = () => <Courses title="Physical Classes" subtitle="Courses available on campus in Chunian." mode="physical" />
export const OnlineLearning = () => <Courses title="Online Learning" subtitle="Courses you can take online. Log in to the Student Portal to access lessons, notes and quizzes." mode="online" />
export const GovernmentPrograms = () => <Courses title="Government Programs" subtitle="Shown only after sponsorship, eligibility and affiliation are verified." type="government" />
export const PrivateProgramsPage = () => <Courses title="Private Programs" subtitle="Institute-run courses with their own fees, schedules and certificates." type="private" />

export function Faculty() {
  const { data, loading } = useQuery((db) => db.from('teachers').select('id,full_name,qualification,bio,photo_url').eq('is_active', true), [])
  return (
    <>
      <PageHeader title="Our Faculty" subtitle="Meet our teachers." />
      <div className="mx-auto max-w-6xl px-4 py-10">
        {loading ? <Spinner /> : !data?.length ? <Empty title="Faculty profiles coming soon" text="Teacher profiles added by the administrator appear here." /> :
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{data.map((t) => (
            <div key={t.id} className="card text-center">
              {t.photo_url ? <img src={t.photo_url} alt={t.full_name} className="mx-auto h-24 w-24 rounded-full object-cover" /> :
                <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-navy-800 text-2xl font-bold text-gold-400">{t.full_name[0]}</div>}
              <h3 className="mt-3 font-bold">{t.full_name}</h3><p className="text-sm text-slate-500">{t.qualification}</p><p className="mt-2 text-sm">{t.bio}</p>
            </div>))}</div>}
      </div>
    </>
  )
}

export function Announcements({ title, subtitle }) {
  const { data, loading } = useQuery((db) => db.from('announcements').select('*').in('audience', ['all', 'public']).order('created_at', { ascending: false }), [])
  return (
    <>
      <PageHeader title={title} subtitle={subtitle} />
      <div className="mx-auto max-w-3xl space-y-3 px-4 py-10">
        {loading ? <Spinner /> : !data?.length ? <Empty title="Nothing posted yet" text="Announcements published by the administration appear here." /> :
          data.map((a) => <div key={a.id} className="card"><p className="text-xs text-slate-500">{new Date(a.created_at).toLocaleDateString()}</p><p className="font-bold">{a.title}</p><p className="mt-1 text-sm">{a.body}</p></div>)}
      </div>
    </>
  )
}
export const Events = () => <Announcements title="Events" subtitle="Seminars, workshops and institute events." />
export const News = () => <Announcements title="News & Updates" subtitle="Latest from the institute." />

export const Gallery = () => (
  <Doc title="Gallery" subtitle="Photos of our campus and events">
    <Empty title="Gallery coming soon" text="Photos will be added once the institute uploads them. Only real photos of the institute should be used here." />
  </Doc>
)

export const Careers = () => (
  <Doc title="Career Opportunities" subtitle="Join our team">
    <p>There are no vacancies listed at the moment. To share your CV for future teaching or staff positions, email <a className="text-royal-500" href={`mailto:${INSTITUTE.email}`}>{INSTITUTE.email}</a> or use the <Link className="text-royal-500" to="/contact">contact form</Link>.</p>
  </Doc>
)

export function FAQs() {
  const { data, loading } = useQuery((db) => db.from('faqs').select('*').eq('is_published', true).order('position'), [])
  return (
    <Doc title="Frequently Asked Questions">
      {loading ? <Spinner /> : !data?.length ? <Empty title="No FAQs yet" /> :
        data.map((f) => <details key={f.id} className="card cursor-pointer"><summary className="font-semibold">{f.question}</summary><p className="mt-2 text-sm">{f.answer}</p></details>)}
    </Doc>
  )
}

export const Privacy = () => (
  <Doc title="Privacy Policy">
    <p className="text-sm text-slate-500">Template text. Please have it reviewed and adjust it to match how your institute actually handles data.</p>
    <H>What we collect</H><p>When you apply or register we collect your name, contact details, CNIC / B-Form number, address, education details and the documents you upload.</p>
    <H>How we use it</H><p>To process admissions, manage fees, attendance, results and certificates, and to contact you about your studies.</p>
    <H>Who can see it</H><p>Your records are visible to you and to authorised administrators and teachers of the institute. We do not sell your data.</p>
    <H>Your choices</H><p>Contact us at {INSTITUTE.email} to correct or request deletion of your information.</p>
  </Doc>
)
export const Terms = () => (
  <Doc title="Terms & Conditions">
    <p className="text-sm text-slate-500">Template text. Please review and adapt before relying on it.</p>
    <H>Admission</H><p>Admission is confirmed only after approval by the administration. Information provided must be true and complete.</p>
    <H>Fees</H><p>Fees must be paid by the due date shown on the voucher. A payment is recorded only after it is verified by the institute.</p>
    <H>Certificates</H><p>Certificates are institute certificates issued after the administration confirms course completion. They are not government-recognised unless officially stated for a specific programme.</p>
    <H>Conduct</H><p>Students must follow the Student Guidelines. The institute may suspend accounts for misconduct.</p>
  </Doc>
)
export const Refund = () => (
  <Doc title="Refund Policy">
    <p className="text-sm text-slate-500">Placeholder. The institute must decide and insert its real refund rules here before launch.</p>
    <p>Refund requests must be made in writing to the administration. Please contact us at {INSTITUTE.phone} or {INSTITUTE.email}.</p>
  </Doc>
)
export const Guidelines = () => (
  <Doc title="Student Guidelines">
    <ul className="list-disc space-y-2 pl-5">
      <li>Attend classes on time and maintain good attendance.</li>
      <li>Treat teachers, staff and fellow students with respect.</li>
      <li>Use institute computers and equipment responsibly.</li>
      <li>Submit assignments by the due date and do your own work.</li>
      <li>Keep your portal password private and never share your account.</li>
    </ul>
  </Doc>
)
