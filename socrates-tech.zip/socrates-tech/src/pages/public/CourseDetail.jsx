import { useEffect } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useQuery } from '../../lib/hooks'
import { PageHeader, Spinner, Empty } from '../../components/ui'
import { money } from '../../lib/config'

const modeLabel = { physical: 'On campus', online: 'Online', both: 'On campus & online' }

export default function CourseDetail() {
  const { slug } = useParams()
  const { data: c, loading } = useQuery((db) => db.from('courses').select('*').eq('slug', slug).maybeSingle(), [slug])

  useEffect(() => { if (c) document.title = `${c.title} | THE SOCRATES TECH. CHUNIAN` }, [c])

  if (loading) return <Spinner />
  if (!c) return <div className="mx-auto max-w-xl py-20"><Empty title="Course not found" action={<Link to="/courses" className="btn-primary">Browse courses</Link>} /></div>

  const rows = [
    ['Duration', c.duration], ['Total fee', Number(c.total_fee) > 0 ? money(c.total_fee) : 'Please contact the institute'],
    ['Monthly fee', Number(c.monthly_fee) > 0 ? money(c.monthly_fee) : 'Please contact the institute'],
    ['Class schedule', c.schedule], ['Availability', modeLabel[c.mode]], ['Certificate', c.certificate_info],
  ]
  const gov = c.course_type === 'government' ? [
    ['Government department / program', c.gov_program_name], ['Eligibility', c.eligibility], ['Available seats', c.seats],
    ['Admission deadline', c.admission_deadline], ['Fee', c.is_free ? 'Free' : 'See fee above'], ['How to apply', c.application_procedure],
  ] : []

  return (
    <>
      <PageHeader title={c.title} subtitle={c.short_description} />
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <div className="card"><h2 className="text-xl font-bold">About this course</h2><p className="mt-2 whitespace-pre-line text-slate-600 dark:text-slate-300">{c.description}</p></div>
          {c.syllabus && <div className="card"><h2 className="text-xl font-bold">Syllabus</h2><p className="mt-2 whitespace-pre-line text-slate-600 dark:text-slate-300">{c.syllabus}</p></div>}
          {gov.length > 0 && <div className="card"><h2 className="text-xl font-bold">Government program details</h2>
            <dl className="mt-3 space-y-2 text-sm">{gov.map(([k, v]) => v != null && v !== '' && <div key={k} className="flex gap-3"><dt className="w-48 shrink-0 font-semibold">{k}</dt><dd>{String(v)}</dd></div>)}</dl></div>}
        </div>
        <aside className="card h-fit">
          <dl className="space-y-3 text-sm">{rows.map(([k, v]) => v && <div key={k}><dt className="text-xs uppercase tracking-wide text-slate-500">{k}</dt><dd className="font-medium">{v}</dd></div>)}</dl>
          <Link to={`/apply?course=${c.id}`} className="btn-gold mt-6 w-full">Apply for this course</Link>
        </aside>
      </div>
    </>
  )
}
