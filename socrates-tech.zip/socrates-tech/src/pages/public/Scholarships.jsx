import { useState } from 'react'
import { supabase, isConfigured } from '../../lib/supabase'
import { useAuth } from '../../lib/AuthContext'
import { useQuery } from '../../lib/hooks'
import { PageHeader, ErrorBox } from '../../components/ui'

const types = [['scholarship', 'Scholarship'], ['fee_concession', 'Fee concession'], ['financial_assistance', 'Financial assistance'], ['free_training', 'Free training opportunity']]

export default function Scholarships() {
  const { user } = useAuth()
  const courses = useQuery((db) => db.from('courses').select('id,title').eq('is_active', true).order('title'), [])
  const [f, setF] = useState({ full_name: '', mobile: '', email: '', course_id: '', request_type: 'scholarship', reason: '', family_income: '' })
  const [s, setS] = useState({ busy: false, done: false, err: '' })
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  async function submit(e) {
    e.preventDefault()
    if (!isConfigured) return setS({ busy: false, done: false, err: 'The database is not configured yet. See README.md.' })
    setS({ busy: true, done: false, err: '' })
    const { error } = await supabase.from('scholarships').insert({ ...f, course_id: f.course_id || null, applicant_id: user?.id || null })
    setS(error ? { busy: false, done: false, err: error.message } : { busy: false, done: true, err: '' })
  }

  return (
    <>
      <PageHeader title="STUDENT SUPPORT & SCHOLARSHIP PROGRAM" subtitle="Need-based support requests are reviewed by the administration, case by case." />
      <div className="mx-auto max-w-4xl space-y-8 px-4 py-10">
        <div className="grid gap-4 sm:grid-cols-2">
          {[['Need-based support', 'Tell us your situation and we will review your request.'], ['Fee concession requests', 'Ask for a concession on your course fee.'],
            ['Financial assistance', 'Request help with fees or learning costs.'], ['Free training opportunities', 'Listed when the institute has confirmed them.'],
            ['Student guidance & career counselling', 'Talk to us about choosing the right course.'], ['Skill development', 'Find programs that fit your goals.']].map(([t, d]) => (
            <div key={t} className="card"><h3 className="font-bold">{t}</h3><p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{d}</p></div>))}
        </div>
        <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-900">Submitting a request does not guarantee a scholarship, concession or funding. Each request is reviewed and decided by the administration.</p>

        <form onSubmit={submit} className="card grid gap-4 sm:grid-cols-2">
          <h2 className="text-xl font-bold sm:col-span-2">Support / scholarship application</h2>
          <div><label className="label">Full name *</label><input className="input" required value={f.full_name} onChange={set('full_name')} /></div>
          <div><label className="label">Mobile *</label><input className="input" required value={f.mobile} onChange={set('mobile')} /></div>
          <div><label className="label">Email</label><input type="email" className="input" value={f.email} onChange={set('email')} /></div>
          <div><label className="label">Request type *</label><select className="input" value={f.request_type} onChange={set('request_type')}>{types.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>
          <div><label className="label">Course of interest</label><select className="input" value={f.course_id} onChange={set('course_id')}><option value="">Not sure yet</option>{(courses.data || []).map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select></div>
          <div><label className="label">Monthly family income (approx.)</label><input className="input" value={f.family_income} onChange={set('family_income')} /></div>
          <div className="sm:col-span-2"><label className="label">Why do you need support? *</label><textarea className="input" rows={5} required minLength={20} value={f.reason} onChange={set('reason')} /></div>
          <div className="sm:col-span-2"><ErrorBox message={s.err} />
            {s.done && <p className="rounded-lg bg-green-50 p-3 text-sm text-green-800">Your request has been submitted for review.</p>}</div>
          <button className="btn-primary sm:col-span-2" disabled={s.busy}>{s.busy ? 'Submitting...' : 'Submit request'}</button>
        </form>
      </div>
    </>
  )
}
