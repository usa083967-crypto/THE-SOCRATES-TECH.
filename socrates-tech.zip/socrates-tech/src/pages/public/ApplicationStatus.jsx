import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { PageHeader, ErrorBox, StatusBadge } from '../../components/ui'

export default function ApplicationStatus() {
  const [code, setCode] = useState('')
  const [cnic, setCnic] = useState('')
  const [res, setRes] = useState(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  async function check(e) {
    e.preventDefault(); setErr(''); setRes(null); setBusy(true)
    const { data, error } = await supabase.rpc('check_application', { code, cnic_no: cnic })
    setBusy(false)
    if (error) return setErr(error.message)
    if (!data?.length) return setErr('No application matches that ID and CNIC. Check both and try again.')
    setRes(data[0])
  }

  return (
    <>
      <PageHeader title="Application Status" subtitle="Enter your application ID and CNIC / B-Form number." />
      <div className="mx-auto max-w-md px-4 py-10">
        <form onSubmit={check} className="card space-y-4">
          <div><label className="label">Application ID</label><input className="input" required value={code} onChange={(e) => setCode(e.target.value)} placeholder="APP-2026-1001" /></div>
          <div><label className="label">CNIC / B-Form</label><input className="input" required value={cnic} onChange={(e) => setCnic(e.target.value)} /></div>
          <ErrorBox message={err} />
          <button className="btn-primary w-full" disabled={busy}>{busy ? 'Checking...' : 'Check status'}</button>
        </form>
        {res && (
          <div className="card mt-6">
            <p className="text-sm text-slate-500">{res.application_code}</p>
            <p className="text-lg font-bold">{res.full_name}</p>
            <p className="mt-2">Status: <StatusBadge status={res.status} /></p>
            {res.admin_note && <p className="mt-3 rounded-lg bg-slate-100 p-3 text-sm dark:bg-white/10">{res.admin_note}</p>}
          </div>)}
      </div>
    </>
  )
}
