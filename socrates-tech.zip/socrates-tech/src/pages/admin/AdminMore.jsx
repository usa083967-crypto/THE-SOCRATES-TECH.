import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../lib/AuthContext'
import { useQuery } from '../../lib/hooks'
import { Spinner, ErrorBox, StatusBadge } from '../../components/ui'
import DataTable from '../../components/DataTable'
import { Title } from './Admin'
import { money } from '../../lib/config'
import { buildVoucher, buildCertificate } from '../../lib/pdf'

const useList = (table, select = '*', order = 'created_at') =>
  useQuery((db) => db.from(table).select(select).order(order, { ascending: false }), [])

async function notifyStudent(studentId, title, body, category) {
  const { data: s } = await supabase.from('students').select('profile_id').eq('id', studentId).maybeSingle()
  if (s?.profile_id) await supabase.from('notifications').insert({ user_id: s.profile_id, title, body, category })
}

/* ---------------- Fees ---------------- */
export function Fees() {
  const { user } = useAuth()
  const fees = useList('fee_records', '*, students(full_name,student_code,father_name,profile_id), enrollments(courses(title))', 'issue_date')
  const students = useQuery((db) => db.from('students').select('id,full_name,student_code').order('full_name'), [])
  const [err, setErr] = useState('')
  const [msg, setMsg] = useState('')
  const [f, setF] = useState(null)
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7))

  async function generateMonthly() {
    setErr(''); setMsg('')
    const { data: enr, error } = await supabase.from('enrollments').select('id,student_id, courses(monthly_fee)').eq('status', 'active')
    if (error) return setErr(error.message)
    const { data: existing } = await supabase.from('fee_records').select('enrollment_id').eq('fee_type', 'monthly').eq('fee_month', month)
    const have = new Set((existing || []).map((x) => x.enrollment_id))
    const rows = enr.filter((e) => !have.has(e.id) && Number(e.courses?.monthly_fee) > 0)
      .map((e) => ({ student_id: e.student_id, enrollment_id: e.id, fee_type: 'monthly', fee_month: month, tuition: e.courses.monthly_fee, due_date: `${month}-10` }))
    if (!rows.length) return setMsg('Nothing to generate: all active enrollments with a monthly fee already have a voucher for this month.')
    const { error: e2 } = await supabase.from('fee_records').insert(rows)
    if (e2) return setErr(e2.message)
    setMsg(`${rows.length} voucher(s) generated.`); fees.reload()
  }

  async function saveManual(e) {
    e.preventDefault(); setErr('')
    const { error } = await supabase.from('fee_records').insert({ student_id: f.student_id, fee_type: f.fee_type, fee_month: f.fee_month || null,
      tuition: Number(f.tuition || 0), other_charges: Number(f.other_charges || 0), discount: Number(f.discount || 0), due_date: f.due_date || null })
    if (error) return setErr(error.message)
    await notifyStudent(f.student_id, 'New fee voucher', 'A new fee voucher has been issued. See Fees & Vouchers.', 'fee')
    setF(null); fees.reload()
  }

  async function markPaid(r) {
    const method = prompt('Payment method (cash, bank transfer, JazzCash, Easypaisa...):')
    if (!method) return
    const ref = prompt('Receipt / transaction reference (optional):') || null
    if (!confirm(`Confirm you have VERIFIED receipt of ${money(r.total_payable)} from ${r.students?.full_name}?`)) return
    const p = await supabase.from('payments').insert({ fee_record_id: r.id, student_id: r.student_id, amount: r.total_payable, method, reference_no: ref, verified_by: user.id })
    if (p.error) return setErr(p.error.message)
    const u = await supabase.from('fee_records').update({ status: 'paid' }).eq('id', r.id)
    if (u.error) return setErr(u.error.message)
    await notifyStudent(r.student_id, 'Payment confirmed', `Payment for voucher ${r.voucher_no} has been verified. Thank you.`, 'fee')
    fees.reload()
  }
  async function remind(r) { await notifyStudent(r.student_id, 'Fee reminder', `Voucher ${r.voucher_no} (${money(r.total_payable)}) is due ${r.due_date || 'soon'}.`, 'fee'); alert('Reminder sent.') }
  async function remove(r) { if (r.status === 'paid') return alert('Paid records cannot be deleted.'); if (!confirm('Delete this voucher?')) return; await supabase.from('fee_records').delete().eq('id', r.id); fees.reload() }

  const rows = (fees.data || []).map((r) => ({ ...r, student: r.students?.full_name, code: r.students?.student_code }))
  const T = (k, label, type = 'text') => <div><label className="label">{label}</label><input type={type} className="input" value={f[k] ?? ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>
  return (
    <div><Title action={<button className="btn-primary" onClick={() => setF({ student_id: '', fee_type: 'admission' })}>New voucher</button>}>Fees & Payments</Title>
      <div className="card mb-4 flex flex-wrap items-end gap-3"><div><label className="label">Generate monthly vouchers for</label><input type="month" className="input" value={month} onChange={(e) => setMonth(e.target.value)} /></div>
        <button className="btn-gold" onClick={generateMonthly}>Generate</button><p className="text-xs text-slate-500">Uses each active enrollment's course monthly fee (courses with monthly fee 0 are skipped).</p></div>
      <ErrorBox message={err || fees.error} />{msg && <p className="mb-3 rounded-lg bg-green-50 p-3 text-sm text-green-800">{msg}</p>}
      {fees.loading ? <Spinner /> : <DataTable exportName="fees" searchKeys={['student', 'code', 'voucher_no', 'fee_month']} rows={rows}
        columns={[{ key: 'voucher_no', label: 'Voucher' }, { key: 'student', label: 'Student' }, { key: 'fee_type', label: 'Type' }, { key: 'fee_month', label: 'Month' }, { key: 'due_date', label: 'Due' },
          { key: 'total_payable', label: 'Total', render: (r) => money(r.total_payable) }, { key: 'status', label: 'Status', render: (r) => <StatusBadge status={r.status} /> },
          { label: 'Actions', render: (r) => <div className="flex flex-wrap gap-1">
            {r.status === 'unpaid' && <><button className="btn-primary !px-2 !py-1" onClick={() => markPaid(r)}>Mark paid</button><button className="btn-outline !px-2 !py-1" onClick={() => remind(r)}>Remind</button></>}
            <button className="btn-outline !px-2 !py-1" onClick={() => buildVoucher(r, r.students, r.enrollments?.courses?.title)}>PDF</button>
            <button className="btn-danger !px-2 !py-1" onClick={() => remove(r)}>Delete</button></div> }]} />}
      {f && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"><form onSubmit={saveManual} className="card w-full max-w-lg space-y-3">
        <h2 className="text-lg font-bold">New fee voucher</h2>
        <div><label className="label">Student *</label><select required className="input" value={f.student_id} onChange={(e) => setF({ ...f, student_id: e.target.value })}><option value="">Select</option>{(students.data || []).map((s) => <option key={s.id} value={s.id}>{s.student_code} - {s.full_name}</option>)}</select></div>
        <div><label className="label">Fee type</label><select className="input" value={f.fee_type} onChange={(e) => setF({ ...f, fee_type: e.target.value })}>{['admission', 'registration', 'course', 'monthly', 'other'].map((t) => <option key={t}>{t}</option>)}</select></div>
        <div className="grid grid-cols-2 gap-3">{T('fee_month', 'Fee month (YYYY-MM)')}{T('due_date', 'Due date', 'date')}{T('tuition', 'Tuition / fee amount', 'number')}{T('other_charges', 'Other charges', 'number')}{T('discount', 'Discount / scholarship', 'number')}</div>
        <ErrorBox message={err} /><div className="flex gap-2"><button className="btn-primary">Create</button><button type="button" className="btn-outline" onClick={() => setF(null)}>Cancel</button></div></form></div>}
    </div>
  )
}

/* ---------------- Attendance ---------------- */
export function AttendanceAdmin() {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const { data, loading, error } = useQuery((db) => db.from('attendance').select('*, students(full_name,student_code), courses(title)').eq('attendance_date', date), [date])
  const rows = (data || []).map((a) => ({ ...a, student: a.students?.full_name, course: a.courses?.title }))
  return (
    <div><Title>Attendance Overview</Title><ErrorBox message={error} />
      <div className="mb-3"><input type="date" className="input max-w-xs" value={date} onChange={(e) => setDate(e.target.value)} /></div>
      {loading ? <Spinner /> : <DataTable exportName={`attendance-${date}`} searchKeys={['student', 'course']} rows={rows} empty="No attendance marked for this date"
        columns={[{ key: 'student', label: 'Student' }, { key: 'course', label: 'Course' }, { key: 'status', label: 'Status' }]} />}
      <p className="mt-3 text-xs text-slate-500">Teachers mark attendance from the Teacher Portal. Admins can also mark attendance by logging in with their own teacher assignment, or add rows in the Supabase table editor.</p>
    </div>
  )
}

/* ---------------- Materials & assignments ---------------- */
export function ContentAdmin() {
  const { user } = useAuth()
  const courses = useQuery((db) => db.from('courses').select('id,title').order('title'), [])
  const mats = useList('materials', '*, courses(title)')
  const asg = useList('assignments', '*, courses(title)')
  const [f, setF] = useState({ kind: 'material', course_id: '', title: '', description: '', due_date: '' })
  const [file, setFile] = useState(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  async function save(e) {
    e.preventDefault(); setErr(''); setBusy(true)
    let path = null
    if (file) {
      if (file.size > 20 * 1024 * 1024) { setBusy(false); return setErr('File must be under 20 MB.') }
      path = `${f.course_id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`
      const up = await supabase.storage.from('materials').upload(path, file)
      if (up.error) { setBusy(false); return setErr(up.error.message) }
    } else if (f.kind === 'material') { setBusy(false); return setErr('Choose a file for the study material.') }
    const res = f.kind === 'material'
      ? await supabase.from('materials').insert({ course_id: f.course_id, title: f.title, file_path: path, uploaded_by: user.id })
      : await supabase.from('assignments').insert({ course_id: f.course_id, title: f.title, description: f.description, file_path: path, due_date: f.due_date || null, created_by: user.id })
    setBusy(false)
    if (res.error) return setErr(res.error.message)
    setF({ ...f, title: '', description: '' }); setFile(null); mats.reload(); asg.reload()
  }
  async function del(table, id, reload) { if (confirm('Delete?')) { await supabase.from(table).delete().eq('id', id); reload() } }

  return (
    <div className="space-y-6"><Title>Study Materials & Assignments</Title>
      <form onSubmit={save} className="card grid gap-3 sm:grid-cols-2">
        <div><label className="label">Type</label><select className="input" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}><option value="material">Study material / notes</option><option value="assignment">Assignment</option></select></div>
        <div><label className="label">Course *</label><select required className="input" value={f.course_id} onChange={(e) => setF({ ...f, course_id: e.target.value })}><option value="">Select</option>{(courses.data || []).map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select></div>
        <div><label className="label">Title *</label><input required className="input" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
        <div><label className="label">File {f.kind === 'material' ? '*' : '(optional)'}</label><input type="file" className="input" onChange={(e) => setFile(e.target.files[0])} /></div>
        {f.kind === 'assignment' && <><div><label className="label">Due date</label><input type="date" className="input" value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} /></div>
          <div className="sm:col-span-2"><label className="label">Instructions</label><textarea className="input" rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div></>}
        <div className="sm:col-span-2"><ErrorBox message={err} /></div>
        <button className="btn-primary sm:col-span-2" disabled={busy}>{busy ? 'Uploading...' : 'Upload'}</button>
      </form>
      <h2 className="font-bold">Materials</h2>
      <DataTable rows={(mats.data || []).map((m) => ({ ...m, course: m.courses?.title }))} searchKeys={['title', 'course']} columns={[{ key: 'title', label: 'Title' }, { key: 'course', label: 'Course' }, { label: '', render: (m) => <button className="btn-danger !px-2 !py-1" onClick={() => del('materials', m.id, mats.reload)}>Delete</button> }]} />
      <h2 className="font-bold">Assignments</h2>
      <DataTable rows={(asg.data || []).map((m) => ({ ...m, course: m.courses?.title }))} searchKeys={['title', 'course']} columns={[{ key: 'title', label: 'Title' }, { key: 'course', label: 'Course' }, { key: 'due_date', label: 'Due' }, { label: '', render: (m) => <button className="btn-danger !px-2 !py-1" onClick={() => del('assignments', m.id, asg.reload)}>Delete</button> }]} />
    </div>
  )
}

/* ---------------- Results ---------------- */
export function ResultsAdmin() {
  const { user } = useAuth()
  const res = useList('results', '*, students(full_name,student_code), courses(title)')
  const students = useQuery((db) => db.from('students').select('id,full_name,student_code').order('full_name'), [])
  const courses = useQuery((db) => db.from('courses').select('id,title').order('title'), [])
  const [f, setF] = useState({ student_id: '', course_id: '', exam_name: '', marks_obtained: '', total_marks: '', grade: '' })
  const [err, setErr] = useState('')

  async function add(e) {
    e.preventDefault(); setErr('')
    if (Number(f.marks_obtained) > Number(f.total_marks)) return setErr('Marks obtained cannot exceed total marks.')
    const { error } = await supabase.from('results').insert({ ...f, marks_obtained: Number(f.marks_obtained), total_marks: Number(f.total_marks), entered_by: user.id })
    if (error) return setErr(error.message)
    setF({ ...f, exam_name: '', marks_obtained: '', total_marks: '', grade: '' }); res.reload()
  }
  async function publish(r) {
    await supabase.from('results').update({ is_published: !r.is_published }).eq('id', r.id)
    if (!r.is_published) await notifyStudent(r.student_id, 'Result published', `Your result for ${r.exam_name} is now available.`, 'exam')
    res.reload()
  }
  async function del(r) { if (confirm('Delete result?')) { await supabase.from('results').delete().eq('id', r.id); res.reload() } }

  return (
    <div className="space-y-6"><Title>Examination Results</Title>
      <form onSubmit={add} className="card grid gap-3 sm:grid-cols-3">
        <select required className="input" value={f.student_id} onChange={(e) => setF({ ...f, student_id: e.target.value })}><option value="">Student *</option>{(students.data || []).map((s) => <option key={s.id} value={s.id}>{s.student_code} - {s.full_name}</option>)}</select>
        <select required className="input" value={f.course_id} onChange={(e) => setF({ ...f, course_id: e.target.value })}><option value="">Course *</option>{(courses.data || []).map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select>
        <input required className="input" placeholder="Exam name *" value={f.exam_name} onChange={(e) => setF({ ...f, exam_name: e.target.value })} />
        <input required type="number" className="input" placeholder="Marks obtained *" value={f.marks_obtained} onChange={(e) => setF({ ...f, marks_obtained: e.target.value })} />
        <input required type="number" className="input" placeholder="Total marks *" value={f.total_marks} onChange={(e) => setF({ ...f, total_marks: e.target.value })} />
        <input className="input" placeholder="Grade" value={f.grade} onChange={(e) => setF({ ...f, grade: e.target.value })} />
        <div className="sm:col-span-3"><ErrorBox message={err} /></div><button className="btn-primary sm:col-span-3">Add result (unpublished)</button>
      </form>
      {res.loading ? <Spinner /> : <DataTable exportName="results" searchKeys={['student', 'exam_name', 'course']} rows={(res.data || []).map((r) => ({ ...r, student: r.students?.full_name, course: r.courses?.title }))}
        columns={[{ key: 'student', label: 'Student' }, { key: 'course', label: 'Course' }, { key: 'exam_name', label: 'Exam' }, { label: 'Marks', render: (r) => `${r.marks_obtained}/${r.total_marks}` }, { key: 'grade', label: 'Grade' },
          { label: 'Published', render: (r) => <button className={`badge ${r.is_published ? 'bg-green-100 text-green-800' : 'bg-slate-200'}`} onClick={() => publish(r)}>{r.is_published ? 'Published' : 'Publish'}</button> },
          { label: '', render: (r) => <button className="btn-danger !px-2 !py-1" onClick={() => del(r)}>Delete</button> }]} />}
    </div>
  )
}

/* ---------------- Certificates ---------------- */
export function CertificatesAdmin() {
  const { user } = useAuth()
  const certs = useList('certificates', '*')
  const enr = useQuery((db) => db.from('enrollments').select('id,student_id,course_id, students(full_name,student_code), courses(title)').order('enrolled_on', { ascending: false }), [])
  const [sel, setSel] = useState('')
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const [err, setErr] = useState('')

  async function issue(e) {
    e.preventDefault(); setErr('')
    const en = enr.data.find((x) => x.id === sel)
    if (!confirm(`Confirm that ${en.students.full_name} has COMPLETED "${en.courses.title}"? A certificate will be issued.`)) return
    const { count } = await supabase.from('certificates').select('*', { count: 'exact', head: true })
    const no = `STC-CERT-${new Date().getFullYear()}-${String((count || 0) + 1001)}`
    const { error } = await supabase.from('certificates').insert({ certificate_no: no, student_id: en.student_id, course_id: en.course_id, student_name: en.students.full_name, course_title: en.courses.title, completion_date: date, issued_by: user.id })
    if (error) return setErr(error.message)
    await supabase.from('enrollments').update({ status: 'completed', progress_percent: 100 }).eq('id', en.id)
    await notifyStudent(en.student_id, 'Certificate issued', `Your certificate for ${en.courses.title} is ready to download.`, 'certificate')
    certs.reload(); setSel('')
  }
  async function revoke(c) { if (confirm('Revoke this certificate? Verification will show it as revoked.')) { await supabase.from('certificates').update({ is_revoked: !c.is_revoked }).eq('id', c.id); certs.reload() } }

  return (
    <div className="space-y-6"><Title>Certificates</Title>
      <form onSubmit={issue} className="card grid gap-3 sm:grid-cols-3"><select required className="input sm:col-span-2" value={sel} onChange={(e) => setSel(e.target.value)}><option value="">Select student and course (course completion must be confirmed by you)</option>{(enr.data || []).map((x) => <option key={x.id} value={x.id}>{x.students?.student_code} - {x.students?.full_name} - {x.courses?.title}</option>)}</select>
        <input type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} /><div className="sm:col-span-3"><ErrorBox message={err} /></div><button className="btn-gold sm:col-span-3">Confirm completion & issue certificate</button></form>
      {certs.loading ? <Spinner /> : <DataTable exportName="certificates" searchKeys={['student_name', 'certificate_no', 'course_title']} rows={certs.data}
        columns={[{ key: 'certificate_no', label: 'Certificate no' }, { key: 'verification_id', label: 'Verification ID' }, { key: 'student_name', label: 'Student' }, { key: 'course_title', label: 'Course' }, { key: 'completion_date', label: 'Completed' },
          { label: 'Actions', render: (c) => <div className="flex gap-1"><button className="btn-outline !px-2 !py-1" onClick={() => buildCertificate(c)}>PDF</button><button className="btn-danger !px-2 !py-1" onClick={() => revoke(c)}>{c.is_revoked ? 'Restore' : 'Revoke'}</button></div> }]} />}
    </div>
  )
}

/* ---------------- Scholarship requests ---------------- */
export function ScholarshipsAdmin() {
  const { data, loading, error, reload } = useList('scholarships', '*, courses(title)')
  async function decide(s, status) {
    const note = prompt('Note to applicant (optional):') ?? null
    await supabase.from('scholarships').update({ status, admin_note: note }).eq('id', s.id)
    if (s.applicant_id) await supabase.from('notifications').insert({ user_id: s.applicant_id, title: `Support request ${status.replace('_', ' ')}`, body: note || '', category: 'scholarship' })
    reload()
  }
  return (
    <div><Title>Scholarship & Support Requests</Title><ErrorBox message={error} />
      {loading ? <Spinner /> : <DataTable exportName="scholarships" searchKeys={['full_name', 'mobile', 'request_type']} rows={(data || []).map((s) => ({ ...s, course: s.courses?.title }))}
        columns={[{ key: 'full_name', label: 'Name' }, { key: 'mobile', label: 'Mobile' }, { key: 'request_type', label: 'Type' }, { key: 'course', label: 'Course' }, { key: 'family_income', label: 'Income' },
          { key: 'reason', label: 'Reason', render: (s) => <span className="line-clamp-3 max-w-xs">{s.reason}</span> }, { key: 'status', label: 'Status', render: (s) => <StatusBadge status={s.status} /> },
          { label: 'Actions', render: (s) => <div className="flex gap-1"><button className="btn-primary !px-2 !py-1" onClick={() => decide(s, 'approved')}>Approve</button><button className="btn-outline !px-2 !py-1" onClick={() => decide(s, 'more_info')}>More info</button><button className="btn-danger !px-2 !py-1" onClick={() => decide(s, 'rejected')}>Reject</button></div> }]} />}
    </div>
  )
}

/* ---------------- Teachers ---------------- */
export function TeachersAdmin() {
  const teachers = useList('teachers', '*, course_teachers(course_id)')
  const courses = useQuery((db) => db.from('courses').select('id,title').order('title'), [])
  const [f, setF] = useState(null)
  const [err, setErr] = useState('')

  async function save(e) {
    e.preventDefault(); setErr('')
    const { id, created_at, course_teachers, login_email, course_ids, ...rest } = f
    let profile_id = rest.profile_id || null
    if (login_email) {
      const { data: p } = await supabase.from('profiles').select('id').eq('email', login_email.trim()).maybeSingle()
      if (!p) return setErr('No registered account uses that email. The teacher must sign up on the website first.')
      profile_id = p.id
      await supabase.from('profiles').update({ role: 'teacher' }).eq('id', p.id)
    }
    const row = { ...rest, profile_id }
    const res = id ? await supabase.from('teachers').update(row).eq('id', id).select().single() : await supabase.from('teachers').insert(row).select().single()
    if (res.error) return setErr(res.error.message)
    await supabase.from('course_teachers').delete().eq('teacher_id', res.data.id)
    if (course_ids?.length) await supabase.from('course_teachers').insert(course_ids.map((cid) => ({ course_id: cid, teacher_id: res.data.id })))
    setF(null); teachers.reload()
  }
  async function del(t) { if (confirm(`Delete ${t.full_name}?`)) { await supabase.from('teachers').delete().eq('id', t.id); teachers.reload() } }
  const chk = (k, label) => <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!f[k]} onChange={(e) => setF({ ...f, [k]: e.target.checked })} /> {label}</label>

  return (
    <div><Title action={<button className="btn-primary" onClick={() => setF({ full_name: '', is_active: true, can_mark_attendance: true, can_upload_materials: true, can_enter_marks: true, course_ids: [] })}>Add teacher</button>}>Teachers & Permissions</Title>
      <ErrorBox message={teachers.error} />
      {teachers.loading ? <Spinner /> : <DataTable searchKeys={['full_name']} rows={teachers.data}
        columns={[{ key: 'full_name', label: 'Name' }, { key: 'qualification', label: 'Qualification' }, { label: 'Login', render: (t) => (t.profile_id ? 'Linked' : 'Not linked') },
          { label: 'Courses', render: (t) => t.course_teachers?.length || 0 },
          { label: 'Permissions', render: (t) => [t.can_mark_attendance && 'attendance', t.can_upload_materials && 'materials', t.can_enter_marks && 'marks'].filter(Boolean).join(', ') || 'none' },
          { label: 'Actions', render: (t) => <div className="flex gap-1"><button className="btn-outline !px-2 !py-1" onClick={() => setF({ ...t, course_ids: t.course_teachers.map((x) => x.course_id) })}>Edit</button><button className="btn-danger !px-2 !py-1" onClick={() => del(t)}>Delete</button></div> }]} />}
      {f && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"><form onSubmit={save} className="card max-h-[92vh] w-full max-w-xl space-y-3 overflow-y-auto">
        <h2 className="text-lg font-bold">{f.id ? 'Edit teacher' : 'Add teacher'}</h2>
        <input required className="input" placeholder="Full name *" value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} />
        <input className="input" placeholder="Qualification" value={f.qualification || ''} onChange={(e) => setF({ ...f, qualification: e.target.value })} />
        <textarea className="input" rows={2} placeholder="Short bio (shown on Faculty page)" value={f.bio || ''} onChange={(e) => setF({ ...f, bio: e.target.value })} />
        <input className="input" placeholder="Photo URL (optional)" value={f.photo_url || ''} onChange={(e) => setF({ ...f, photo_url: e.target.value })} />
        <input className="input" placeholder="Login email (teacher must sign up first) - gives them Teacher Portal access" value={f.login_email || ''} onChange={(e) => setF({ ...f, login_email: e.target.value })} />
        <div><p className="label">Assigned courses</p><div className="grid max-h-36 gap-1 overflow-y-auto sm:grid-cols-2">{(courses.data || []).map((c) => <label key={c.id} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.course_ids.includes(c.id)} onChange={(e) => setF({ ...f, course_ids: e.target.checked ? [...f.course_ids, c.id] : f.course_ids.filter((x) => x !== c.id) })} /> {c.title}</label>)}</div></div>
        <div className="space-y-1">{chk('can_mark_attendance', 'Can mark attendance')}{chk('can_upload_materials', 'Can upload notes & assignments')}{chk('can_enter_marks', 'Can enter marks')}{chk('is_active', 'Active')}</div>
        <ErrorBox message={err} /><div className="flex gap-2"><button className="btn-primary">Save</button><button type="button" className="btn-outline" onClick={() => setF(null)}>Cancel</button></div></form></div>}
    </div>
  )
}

/* ---------------- Announcements ---------------- */
export function AnnouncementsAdmin() {
  const { user } = useAuth()
  const { data, loading, error, reload } = useList('announcements')
  const [f, setF] = useState({ title: '', body: '', audience: 'all', notify: true })
  const [err, setErr] = useState('')
  async function send(e) {
    e.preventDefault(); setErr('')
    const { notify, ...row } = f
    const { error: er } = await supabase.from('announcements').insert({ ...row, created_by: user.id })
    if (er) return setErr(er.message)
    if (notify) await supabase.from('notifications').insert({ user_id: null, title: f.title, body: f.body, category: 'announcement' })
    setF({ title: '', body: '', audience: 'all', notify: true }); reload()
  }
  return (
    <div className="space-y-6"><Title>Announcements</Title>
      <form onSubmit={send} className="card space-y-3"><input required className="input" placeholder="Title *" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
        <textarea className="input" rows={3} placeholder="Message" value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} />
        <div className="flex flex-wrap items-center gap-4"><select className="input max-w-[12rem]" value={f.audience} onChange={(e) => setF({ ...f, audience: e.target.value })}><option value="all">Everyone (public)</option><option value="students">Students only</option><option value="teachers">Teachers only</option></select>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.notify} onChange={(e) => setF({ ...f, notify: e.target.checked })} /> Also send in-app notification</label></div>
        <ErrorBox message={err || error} /><button className="btn-primary">Publish</button></form>
      {loading ? <Spinner /> : <DataTable searchKeys={['title']} rows={data} columns={[{ key: 'title', label: 'Title' }, { key: 'audience', label: 'Audience' }, { key: 'created_at', label: 'Date', render: (a) => new Date(a.created_at).toLocaleDateString() },
        { label: '', render: (a) => <button className="btn-danger !px-2 !py-1" onClick={async () => { if (confirm('Delete?')) { await supabase.from('announcements').delete().eq('id', a.id); reload() } }}>Delete</button> }]} />}
    </div>
  )
}

/* ---------------- Contact messages ---------------- */
export function MessagesAdmin() {
  const { data, loading, error, reload } = useList('contact_messages')
  const [kind, setKind] = useState('all')
  async function set(m, status) { await supabase.from('contact_messages').update({ status }).eq('id', m.id); reload() }
  const rows = (data || []).filter((m) => kind === 'all' || m.kind === kind)
  return (
    <div><Title>Contact Messages, Support & Complaints</Title><ErrorBox message={error} />
      {loading ? <Spinner /> : <DataTable exportName="messages" searchKeys={['name', 'email', 'subject', 'message']} rows={rows}
        filter={<select className="input max-w-[10rem]" value={kind} onChange={(e) => setKind(e.target.value)}><option value="all">All</option><option value="contact">Contact</option><option value="support">Support</option><option value="complaint">Complaints</option></select>}
        columns={[{ key: 'kind', label: 'Kind' }, { key: 'name', label: 'From' }, { label: 'Contact', render: (m) => <span className="text-xs">{m.email}<br />{m.phone}</span> }, { key: 'subject', label: 'Subject' },
          { key: 'message', label: 'Message', render: (m) => <span className="block max-w-sm whitespace-pre-line">{m.message}</span> }, { key: 'status', label: 'Status', render: (m) => <StatusBadge status={m.status} /> },
          { label: 'Actions', render: (m) => <div className="flex gap-1"><button className="btn-outline !px-2 !py-1" onClick={() => set(m, 'in_progress')}>In progress</button><button className="btn-primary !px-2 !py-1" onClick={() => set(m, 'resolved')}>Resolve</button></div> }]} />}
    </div>
  )
}

/* ---------------- Website content ---------------- */
function Simple({ table, title, fields, cols }) {
  const { data, loading, error, reload } = useList(table)
  const [f, setF] = useState(null)
  const [err, setErr] = useState('')
  async function save(e) {
    e.preventDefault(); setErr('')
    const { id, created_at, ...row } = f
    const res = id ? await supabase.from(table).update(row).eq('id', id) : await supabase.from(table).insert(row)
    if (res.error) return setErr(res.error.message); setF(null); reload()
  }
  return (
    <div className="space-y-3"><div className="flex items-center justify-between"><h2 className="text-lg font-bold">{title}</h2><button className="btn-primary !py-1.5" onClick={() => setF(Object.fromEntries(fields.map(([k, , t]) => [k, t === 'bool' ? true : ''])))}>Add</button></div>
      <ErrorBox message={error} />
      {loading ? <Spinner /> : <DataTable rows={data} columns={[...cols, { label: '', render: (r) => <div className="flex gap-1"><button className="btn-outline !px-2 !py-1" onClick={() => setF(r)}>Edit</button><button className="btn-danger !px-2 !py-1" onClick={async () => { if (confirm('Delete?')) { await supabase.from(table).delete().eq('id', r.id); reload() } }}>Delete</button></div> }]} />}
      {f && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"><form onSubmit={save} className="card w-full max-w-lg space-y-3">
        {fields.map(([k, label, t]) => t === 'bool' ? <label key={k} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!f[k]} onChange={(e) => setF({ ...f, [k]: e.target.checked })} /> {label}</label>
          : t === 'area' ? <div key={k}><label className="label">{label}</label><textarea className="input" rows={3} value={f[k] || ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>
          : <div key={k}><label className="label">{label}</label><input className="input" type={t || 'text'} value={f[k] ?? ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>)}
        <ErrorBox message={err} /><div className="flex gap-2"><button className="btn-primary">Save</button><button type="button" className="btn-outline" onClick={() => setF(null)}>Cancel</button></div></form></div>}
    </div>
  )
}

export function WebsiteAdmin() {
  return (
    <div className="space-y-10"><Title>Website Content</Title>
      <p className="text-sm text-slate-500">Testimonials appear on the homepage only when "Published" is ticked. Add only real feedback from real students.</p>
      <Simple table="testimonials" title="Student testimonials" cols={[{ key: 'name', label: 'Name' }, { key: 'course', label: 'Course' }, { key: 'quote', label: 'Quote' }, { key: 'is_published', label: 'Published', render: (r) => (r.is_published ? 'Yes' : 'No') }]}
        fields={[['name', 'Student name'], ['course', 'Course'], ['quote', 'Quote', 'area'], ['is_published', 'Published', 'bool']]} />
      <Simple table="banners" title="Banners" cols={[{ key: 'title', label: 'Title' }, { key: 'subtitle', label: 'Subtitle' }, { key: 'is_active', label: 'Active', render: (r) => (r.is_active ? 'Yes' : 'No') }]}
        fields={[['title', 'Title'], ['subtitle', 'Subtitle'], ['link', 'Link'], ['is_active', 'Active', 'bool']]} />
      <Simple table="faqs" title="FAQs" cols={[{ key: 'question', label: 'Question' }, { key: 'position', label: 'Order' }, { key: 'is_published', label: 'Published', render: (r) => (r.is_published ? 'Yes' : 'No') }]}
        fields={[['question', 'Question'], ['answer', 'Answer', 'area'], ['position', 'Order', 'number'], ['is_published', 'Published', 'bool']]} />
    </div>
  )
}
