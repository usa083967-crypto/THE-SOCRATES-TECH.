import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../lib/AuthContext'
import { useQuery } from '../../lib/hooks'
import { Spinner, ErrorBox, StatusBadge } from '../../components/ui'
import DataTable from '../../components/DataTable'
import { money } from '../../lib/config'

export const Title = ({ children, action }) => <div className="mb-5 flex items-center justify-between"><h1 className="text-2xl font-bold">{children}</h1>{action}</div>

const count = (db, table, build) => {
  let q = db.from(table).select('*', { count: 'exact', head: true })
  if (build) q = build(q)
  return q.then((r) => ({ data: r.count, error: r.error }))
}

function Stat({ label, value }) {
  return <div className="card"><p className="text-xs uppercase tracking-wide text-slate-500">{label}</p><p className="mt-1 text-2xl font-bold">{value ?? '...'}</p></div>
}

export function Dashboard() {
  const month = new Date().toISOString().slice(0, 7)
  const q = (t, b) => useQuery((db) => count(db, t, b), []) // eslint-disable-line react-hooks/rules-of-hooks
  const students = q('students'); const active = q('students', (x) => x.eq('status', 'active'))
  const pending = q('applications', (x) => x.eq('status', 'pending')); const approved = q('applications', (x) => x.eq('status', 'approved'))
  const rejected = q('applications', (x) => x.eq('status', 'rejected'))
  const newApps = q('applications', (x) => x.gte('created_at', month + '-01'))
  const courses = q('courses'); const gov = q('courses', (x) => x.eq('course_type', 'government')); const priv = q('courses', (x) => x.eq('course_type', 'private'))
  const pays = useQuery((db) => db.from('payments').select('amount,paid_on'), [])
  const unpaid = useQuery((db) => db.from('fee_records').select('total_payable').eq('status', 'unpaid'), [])
  const att = useQuery((db) => db.from('attendance').select('status'), [])

  const sum = (a, k) => (a || []).reduce((s, x) => s + Number(x[k]), 0)
  const presentPct = att.data?.length ? Math.round((att.data.filter((a) => a.status === 'present' || a.status === 'late').length / att.data.length) * 100) + '%' : 'No data'

  return (
    <div><Title>Dashboard</Title>
      <p className="mb-4 text-sm text-slate-500">All numbers below are live from the database. A new installation shows zeros until you add data.</p>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Total students" value={students.data} /><Stat label="Active students" value={active.data} />
        <Stat label="New applications (this month)" value={newApps.data} /><Stat label="Pending applications" value={pending.data} />
        <Stat label="Approved admissions" value={approved.data} /><Stat label="Rejected applications" value={rejected.data} />
        <Stat label="Total courses" value={courses.data} /><Stat label="Government courses" value={gov.data} />
        <Stat label="Private courses" value={priv.data} />
        <Stat label="Total fee collection" value={pays.data ? money(sum(pays.data, 'amount')) : '...'} />
        <Stat label="Pending fees" value={unpaid.data ? money(sum(unpaid.data, 'total_payable')) : '...'} />
        <Stat label="Revenue this month" value={pays.data ? money(sum(pays.data.filter((p) => p.paid_on?.startsWith(month)), 'amount')) : '...'} />
        <Stat label="Attendance overview" value={att.data ? presentPct : '...'} />
      </div>
    </div>
  )
}

export function Applications() {
  const { user } = useAuth()
  const [status, setStatus] = useState('all')
  const { data, loading, error, reload } = useQuery((db) => db.from('applications').select('*, courses(title)').order('created_at', { ascending: false }), [])
  const [err, setErr] = useState('')
  const [sel, setSel] = useState(null)

  async function docUrl(path) {
    const { data: d, error: e } = await supabase.storage.from('applications').createSignedUrl(path, 120)
    if (e) return alert(e.message); window.open(d.signedUrl, '_blank')
  }

  async function decide(a, newStatus) {
    setErr('')
    const note = newStatus === 'approved' ? null : prompt(newStatus === 'rejected' ? 'Reason for rejection (shown to student):' : 'What needs to be corrected? (shown to student)')
    if (newStatus !== 'approved' && note === null) return
    let studentId = a.student_id
    if (newStatus === 'approved' && !studentId) {
      const { data: st, error: e1 } = await supabase.from('students').insert({
        profile_id: a.applicant_id, full_name: a.full_name, father_name: a.father_name, dob: a.dob, gender: a.gender, cnic: a.cnic,
        mobile: a.mobile, whatsapp: a.whatsapp, email: a.email, address: a.address, city: a.city, qualification: a.qualification, photo_path: a.photo_path,
      }).select().single()
      if (e1) return setErr(e1.message + ' (If this account already has a student record, link manually in Students.)')
      studentId = st.id
      if (a.course_id) {
        const { error: e2 } = await supabase.from('enrollments').insert({ student_id: studentId, course_id: a.course_id, learning_mode: a.learning_mode })
        if (e2) return setErr(e2.message)
      }
    }
    const { error: e3 } = await supabase.from('applications').update({ status: newStatus, admin_note: note, student_id: studentId }).eq('id', a.id)
    if (e3) return setErr(e3.message)
    if (a.applicant_id) {
      await supabase.from('notifications').insert({ user_id: a.applicant_id, category: 'admission',
        title: `Application ${newStatus.replace('_', ' ')}`, body: `Your application ${a.application_code} is ${newStatus.replace('_', ' ')}.${note ? ' ' + note : ''}` })
    }
    reload()
  }

  const rows = (data || []).filter((a) => status === 'all' || a.status === status).map((a) => ({ ...a, course: a.courses?.title }))
  return (
    <div><Title>Admission Applications</Title><ErrorBox message={err || error} />
      {loading ? <Spinner /> : <DataTable exportName="applications" searchKeys={['full_name', 'application_code', 'cnic', 'mobile']} rows={rows}
        filter={<select className="input max-w-[11rem]" value={status} onChange={(e) => setStatus(e.target.value)}><option value="all">All statuses</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option><option value="correction_requested">Correction requested</option></select>}
        columns={[{ key: 'application_code', label: 'ID' }, { key: 'full_name', label: 'Name' }, { key: 'course', label: 'Course' }, { key: 'learning_mode', label: 'Mode' },
          { key: 'status', label: 'Status', render: (a) => <StatusBadge status={a.status} /> },
          { label: 'Actions', render: (a) => (
            <div className="flex flex-wrap gap-1"><button className="btn-outline !px-2 !py-1" onClick={() => setSel(a)}>View</button>
              {a.status !== 'approved' && <button className="btn-primary !px-2 !py-1" onClick={() => decide(a, 'approved')}>Approve</button>}
              {a.status === 'pending' && <><button className="btn-outline !px-2 !py-1" onClick={() => decide(a, 'correction_requested')}>Correction</button><button className="btn-danger !px-2 !py-1" onClick={() => decide(a, 'rejected')}>Reject</button></>}</div>) }]} />}
      {sel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setSel(null)}>
          <div className="card max-h-[90vh] w-full max-w-lg overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <h2 className="mb-3 text-lg font-bold">{sel.full_name} · {sel.application_code}</h2>
            <dl className="space-y-1 text-sm">{[['Father', sel.father_name], ['DOB', sel.dob], ['Gender', sel.gender], ['CNIC', sel.cnic], ['Mobile', sel.mobile], ['WhatsApp', sel.whatsapp], ['Email', sel.email], ['Address', sel.address], ['City', sel.city], ['Qualification', sel.qualification], ['Course', sel.course], ['Mode', sel.learning_mode], ['Admin note', sel.admin_note]].map(([k, v]) => <div key={k}><dt className="inline font-semibold">{k}: </dt><dd className="inline">{v || '-'}</dd></div>)}</dl>
            <div className="mt-4 flex flex-wrap gap-2">{[['photo_path', 'Photo'], ['cnic_doc_path', 'CNIC doc'], ['education_doc_path', 'Education doc']].map(([k, l]) => sel[k] && <button key={k} className="btn-outline !py-1.5" onClick={() => docUrl(sel[k])}>{l}</button>)}</div>
            <button className="btn-primary mt-4" onClick={() => setSel(null)}>Close</button>
          </div></div>)}
    </div>
  )
}

export function Students() {
  const { data, loading, error, reload } = useQuery((db) => db.from('students').select('*').order('created_at', { ascending: false }), [])
  const [f, setF] = useState(null)
  const [err, setErr] = useState('')

  async function save(e) {
    e.preventDefault(); setErr('')
    const { id, created_at, student_code, link_email, ...rest } = f
    let payload = { ...rest }
    if (link_email) {
      const { data: p } = await supabase.from('profiles').select('id').eq('email', link_email.trim()).maybeSingle()
      if (!p) return setErr('No registered account uses that email. The student must sign up first.')
      payload.profile_id = p.id
    }
    const res = id ? await supabase.from('students').update(payload).eq('id', id) : await supabase.from('students').insert(payload)
    if (res.error) return setErr(res.error.message)
    setF(null); reload()
  }
  async function remove(s) {
    if (!confirm(`Delete ${s.full_name}? This also deletes their fees, attendance and results.`)) return
    const { error: e } = await supabase.from('students').delete().eq('id', s.id)
    if (e) setErr(e.message); else reload()
  }
  const field = (k, label, type = 'text') => <div><label className="label">{label}</label><input type={type} className="input" value={f[k] || ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>

  return (
    <div><Title action={<button className="btn-primary" onClick={() => setF({ full_name: '', status: 'active' })}>Add student</button>}>Students</Title>
      <ErrorBox message={err || error} />
      {loading ? <Spinner /> : <DataTable exportName="students" searchKeys={['full_name', 'student_code', 'cnic', 'mobile']} rows={data}
        columns={[{ key: 'student_code', label: 'Student ID' }, { key: 'full_name', label: 'Name' }, { key: 'father_name', label: 'Father' }, { key: 'mobile', label: 'Mobile' },
          { key: 'status', label: 'Status', render: (s) => <StatusBadge status={s.status} /> },
          { label: 'Account', render: (s) => (s.profile_id ? 'Linked' : <span className="text-amber-600">Not linked</span>) },
          { label: 'Actions', render: (s) => <div className="flex gap-1"><button className="btn-outline !px-2 !py-1" onClick={() => setF(s)}>Edit</button><button className="btn-danger !px-2 !py-1" onClick={() => remove(s)}>Delete</button></div> }]} />}
      {f && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={save} className="card max-h-[90vh] w-full max-w-2xl space-y-3 overflow-y-auto">
            <h2 className="text-lg font-bold">{f.id ? 'Edit student' : 'Add student'}</h2>
            <div className="grid gap-3 sm:grid-cols-2">{field('full_name', 'Full name *')}{field('father_name', "Father's name")}{field('cnic', 'CNIC')}{field('mobile', 'Mobile')}{field('whatsapp', 'WhatsApp')}{field('email', 'Email')}{field('city', 'City')}{field('qualification', 'Qualification')}{field('dob', 'Date of birth', 'date')}
              <div><label className="label">Status</label><select className="input" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}><option value="active">Active</option><option value="inactive">Inactive</option><option value="completed">Completed</option></select></div></div>
            {field('address', 'Address')}
            <div><label className="label">Link to login account (email the student signed up with)</label><input className="input" value={f.link_email || ''} onChange={(e) => setF({ ...f, link_email: e.target.value })} /></div>
            <ErrorBox message={err} />
            <div className="flex gap-2"><button className="btn-primary">Save</button><button type="button" className="btn-outline" onClick={() => setF(null)}>Cancel</button></div>
          </form></div>)}
    </div>
  )
}

const slugify = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')

export function CoursesAdmin() {
  const { data, loading, error, reload } = useQuery((db) => db.from('courses').select('*').order('title'), [])
  const [f, setF] = useState(null)
  const [err, setErr] = useState('')

  async function save(e) {
    e.preventDefault(); setErr('')
    const { id, created_at, ...rest } = f
    const payload = { ...rest, slug: rest.slug || slugify(rest.title), seats: rest.seats === '' ? null : rest.seats, admission_deadline: rest.admission_deadline || null }
    if (payload.course_type === 'government' && payload.is_verified && !payload.gov_program_name) return setErr('Enter the government department / program name before marking it verified.')
    const res = id ? await supabase.from('courses').update(payload).eq('id', id) : await supabase.from('courses').insert(payload)
    if (res.error) return setErr(res.error.message)
    setF(null); reload()
  }
  async function toggle(c) { await supabase.from('courses').update({ is_active: !c.is_active }).eq('id', c.id); reload() }
  async function remove(c) { if (!confirm(`Delete course "${c.title}"?`)) return; const { error: e } = await supabase.from('courses').delete().eq('id', c.id); if (e) setErr(e.message); else reload() }

  const T = (k, label, type = 'text') => <div><label className="label">{label}</label><input type={type} className="input" value={f[k] ?? ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>
  const gov = f?.course_type === 'government'
  return (
    <div><Title action={<button className="btn-primary" onClick={() => setF({ title: '', category: 'Computer & IT', course_type: 'private', mode: 'both', is_active: true, is_verified: false, total_fee: 0, monthly_fee: 0 })}>Add course</button>}>Courses</Title>
      <ErrorBox message={err || error} />
      {loading ? <Spinner /> : <DataTable exportName="courses" searchKeys={['title', 'category']} rows={data}
        columns={[{ key: 'title', label: 'Title' }, { key: 'category', label: 'Category' }, { key: 'course_type', label: 'Type' }, { key: 'total_fee', label: 'Fee', render: (c) => money(c.total_fee) },
          { key: 'is_active', label: 'Active', render: (c) => <button className={`badge ${c.is_active ? 'bg-green-100 text-green-800' : 'bg-slate-200'}`} onClick={() => toggle(c)}>{c.is_active ? 'Active' : 'Inactive'}</button> },
          { label: 'Actions', render: (c) => <div className="flex gap-1"><button className="btn-outline !px-2 !py-1" onClick={() => setF({ ...c })}>Edit</button><button className="btn-danger !px-2 !py-1" onClick={() => remove(c)}>Delete</button></div> }]} />}
      {f && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={save} className="card max-h-[92vh] w-full max-w-2xl space-y-3 overflow-y-auto">
            <h2 className="text-lg font-bold">{f.id ? 'Edit course' : 'Add course'}</h2>
            <div className="grid gap-3 sm:grid-cols-2">{T('title', 'Title *')}{T('category', 'Category')}
              <div><label className="label">Type</label><select className="input" value={f.course_type} onChange={(e) => setF({ ...f, course_type: e.target.value })}><option value="private">Private</option><option value="government">Government</option></select></div>
              <div><label className="label">Mode</label><select className="input" value={f.mode} onChange={(e) => setF({ ...f, mode: e.target.value })}><option value="both">Physical & online</option><option value="physical">Physical</option><option value="online">Online</option></select></div>
              {T('duration', 'Duration')}{T('schedule', 'Class schedule')}{T('total_fee', 'Total fee (Rs.)', 'number')}{T('monthly_fee', 'Monthly fee (Rs.)', 'number')}</div>
            {T('short_description', 'Short description')}
            <div><label className="label">Full description</label><textarea className="input" rows={3} value={f.description || ''} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
            <div><label className="label">Syllabus</label><textarea className="input" rows={3} value={f.syllabus || ''} onChange={(e) => setF({ ...f, syllabus: e.target.value })} /></div>
            {T('certificate_info', 'Certificate details')}
            {gov && <div className="space-y-3 rounded-xl border border-amber-300 bg-amber-50 p-3 dark:bg-amber-950/20">
              <p className="text-sm font-semibold">Government program (shown publicly only when "Verified" is ticked)</p>
              <div className="grid gap-3 sm:grid-cols-2">{T('gov_program_name', 'Department / program name')}{T('seats', 'Available seats', 'number')}{T('admission_deadline', 'Admission deadline', 'date')}{T('eligibility', 'Eligibility criteria')}</div>
              {T('application_procedure', 'Application procedure')}
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!f.is_free} onChange={(e) => setF({ ...f, is_free: e.target.checked })} /> Free of charge</label>
              <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={!!f.is_verified} onChange={(e) => setF({ ...f, is_verified: e.target.checked })} /> I have verified this sponsorship, eligibility and affiliation with the official source</label></div>}
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!f.is_active} onChange={(e) => setF({ ...f, is_active: e.target.checked })} /> Active (visible on website)</label>
            <ErrorBox message={err} />
            <div className="flex gap-2"><button className="btn-primary">Save</button><button type="button" className="btn-outline" onClick={() => setF(null)}>Cancel</button></div>
          </form></div>)}
    </div>
  )
}
