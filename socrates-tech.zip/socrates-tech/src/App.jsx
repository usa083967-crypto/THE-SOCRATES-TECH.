import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout'
import PortalShell from './components/PortalShell'
import ProtectedRoute from './components/ProtectedRoute'
import Home from './pages/public/Home'
import Courses from './pages/public/Courses'
import CourseDetail from './pages/public/CourseDetail'
import Apply from './pages/public/Apply'
import ApplicationStatus from './pages/public/ApplicationStatus'
import Contact from './pages/public/Contact'
import Scholarships from './pages/public/Scholarships'
import VerifyCertificate from './pages/public/VerifyCertificate'
import { Login, Signup, ForgotPassword, ResetPassword } from './pages/public/Auth'
import * as S from './pages/public/StaticPages'
import * as ST from './pages/student/Student'
import * as AD from './pages/admin/Admin'
import * as AD2 from './pages/admin/AdminMore'
import * as TE from './pages/teacher/Teacher'

const studentNav = [
  ['/student', 'Overview', true], ['/student/courses', 'My Courses & Lessons'], ['/student/fees', 'Fees & Vouchers'], ['/student/attendance', 'Attendance'],
  ['/student/timetable', 'Timetable'], ['/student/results', 'Results'], ['/student/assignments', 'Assignments'], ['/student/materials', 'Study Materials'],
  ['/student/certificates', 'Certificates'], ['/student/notifications', 'Notifications'], ['/student/support', 'Support & Complaints'], ['/student/password', 'Change Password'],
]
const adminNav = [
  ['/admin', 'Dashboard', true], ['/admin/applications', 'Applications'], ['/admin/students', 'Students'], ['/admin/courses', 'Courses'],
  ['/admin/fees', 'Fees & Payments'], ['/admin/attendance', 'Attendance'], ['/admin/content', 'Materials & Assignments'], ['/admin/results', 'Results'],
  ['/admin/certificates', 'Certificates'], ['/admin/scholarships', 'Scholarship Requests'], ['/admin/teachers', 'Teachers & Permissions'],
  ['/admin/announcements', 'Announcements'], ['/admin/messages', 'Contact Messages'], ['/admin/website', 'Website Content'],
]
const teacherNav = [['/teacher', 'My Classes', true], ['/teacher/attendance', 'Attendance'], ['/teacher/materials', 'Notes & Assignments'], ['/teacher/marks', 'Enter Marks'], ['/teacher/timetable', 'Timetable']]

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="about" element={<S.About />} />
        <Route path="courses" element={<Courses />} />
        <Route path="courses/:slug" element={<CourseDetail />} />
        <Route path="admissions" element={<S.Admissions />} />
        <Route path="apply" element={<Apply />} />
        <Route path="application-status" element={<ApplicationStatus />} />
        <Route path="physical-classes" element={<S.PhysicalClasses />} />
        <Route path="online-learning" element={<S.OnlineLearning />} />
        <Route path="government-programs" element={<S.GovernmentPrograms />} />
        <Route path="private-programs" element={<S.PrivateProgramsPage />} />
        <Route path="scholarships" element={<Scholarships />} />
        <Route path="faculty" element={<S.Faculty />} />
        <Route path="gallery" element={<S.Gallery />} />
        <Route path="events" element={<S.Events />} />
        <Route path="news" element={<S.News />} />
        <Route path="careers" element={<S.Careers />} />
        <Route path="faqs" element={<S.FAQs />} />
        <Route path="contact" element={<Contact />} />
        <Route path="privacy-policy" element={<S.Privacy />} />
        <Route path="terms" element={<S.Terms />} />
        <Route path="refund-policy" element={<S.Refund />} />
        <Route path="student-guidelines" element={<S.Guidelines />} />
        <Route path="verify-certificate" element={<VerifyCertificate />} />
        <Route path="login" element={<Login kind="student" />} />
        <Route path="signup" element={<Signup />} />
        <Route path="teacher-login" element={<Login kind="teacher" />} />
        <Route path="admin-login" element={<Login kind="admin" />} />
        <Route path="forgot-password" element={<ForgotPassword />} />
        <Route path="reset-password" element={<ResetPassword />} />
      </Route>

      <Route path="/student" element={<ProtectedRoute roles={['student']}><PortalShell title="Student Portal" items={studentNav} /></ProtectedRoute>}>
        <Route index element={<ST.Overview />} />
        <Route path="courses" element={<ST.MyCourses />} />
        <Route path="fees" element={<ST.Fees />} />
        <Route path="attendance" element={<ST.Attendance />} />
        <Route path="timetable" element={<ST.Timetable />} />
        <Route path="results" element={<ST.Results />} />
        <Route path="assignments" element={<ST.Assignments />} />
        <Route path="materials" element={<ST.Materials />} />
        <Route path="certificates" element={<ST.Certificates />} />
        <Route path="notifications" element={<ST.Notifications />} />
        <Route path="support" element={<ST.Support />} />
        <Route path="password" element={<ST.ChangePassword />} />
      </Route>

      <Route path="/admin" element={<ProtectedRoute roles={['admin']}><PortalShell title="Admin Panel" items={adminNav} /></ProtectedRoute>}>
        <Route index element={<AD.Dashboard />} />
        <Route path="applications" element={<AD.Applications />} />
        <Route path="students" element={<AD.Students />} />
        <Route path="courses" element={<AD.CoursesAdmin />} />
        <Route path="fees" element={<AD2.Fees />} />
        <Route path="attendance" element={<AD2.AttendanceAdmin />} />
        <Route path="content" element={<AD2.ContentAdmin />} />
        <Route path="results" element={<AD2.ResultsAdmin />} />
        <Route path="certificates" element={<AD2.CertificatesAdmin />} />
        <Route path="scholarships" element={<AD2.ScholarshipsAdmin />} />
        <Route path="teachers" element={<AD2.TeachersAdmin />} />
        <Route path="announcements" element={<AD2.AnnouncementsAdmin />} />
        <Route path="messages" element={<AD2.MessagesAdmin />} />
        <Route path="website" element={<AD2.WebsiteAdmin />} />
      </Route>

      <Route path="/teacher" element={<ProtectedRoute roles={['teacher']}><PortalShell title="Teacher Portal" items={teacherNav} /></ProtectedRoute>}>
        <Route index element={<TE.Classes />} />
        <Route path="attendance" element={<TE.AttendanceTeacher />} />
        <Route path="materials" element={<TE.MaterialsTeacher />} />
        <Route path="marks" element={<TE.MarksTeacher />} />
        <Route path="timetable" element={<TE.TimetableTeacher />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
