import { useState } from 'react'
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { Menu, X, Moon, Sun, Phone, Mail, MessageCircle, MapPin } from 'lucide-react'
import { Logo, SetupNotice } from './ui'
import { INSTITUTE, waLink } from '../lib/config'
import { useAuth } from '../lib/AuthContext'

const links = [
  ['/', 'Home'], ['/about', 'About'], ['/courses', 'Courses'], ['/admissions', 'Admissions'],
  ['/online-learning', 'Online Learning'], ['/scholarships', 'Scholarships'], ['/faculty', 'Faculty'], ['/contact', 'Contact'],
]

function portalPath(role) {
  return role === 'admin' ? '/admin' : role === 'teacher' ? '/teacher' : '/student'
}

export default function Layout() {
  const [open, setOpen] = useState(false)
  const [dark, setDark] = useState(document.documentElement.classList.contains('dark'))
  const { user, role, signOut } = useAuth()
  const nav = useNavigate()

  const toggleTheme = () => {
    const next = !dark
    setDark(next)
    document.documentElement.classList.toggle('dark', next)
    localStorage.setItem('theme', next ? 'dark' : 'light')
  }

  return (
    <div className="flex min-h-screen flex-col">
      <SetupNotice />
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-white/10 dark:bg-navy-950/90">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link to="/"><Logo /></Link>
          <nav className="hidden items-center gap-5 lg:flex">
            {links.map(([to, label]) => (
              <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `text-sm font-medium hover:text-royal-500 ${isActive ? 'text-royal-500' : ''}`}>{label}</NavLink>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={toggleTheme} aria-label="Toggle dark mode" className="rounded-lg p-2 hover:bg-slate-100 dark:hover:bg-white/10">
              {dark ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            {user ? (
              <>
                <Link to={portalPath(role)} className="btn-primary hidden sm:inline-flex">My Portal</Link>
                <button className="btn-outline hidden sm:inline-flex" onClick={async () => { await signOut(); nav('/') }}>Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-outline hidden sm:inline-flex">Student Portal</Link>
                <Link to="/apply" className="btn-gold hidden sm:inline-flex">Apply Now</Link>
              </>
            )}
            <button className="rounded-lg p-2 lg:hidden" onClick={() => setOpen(!open)} aria-label="Menu">{open ? <X /> : <Menu />}</button>
          </div>
        </div>
        {open && (
          <div className="border-t border-slate-200 px-4 pb-4 lg:hidden dark:border-white/10">
            {links.map(([to, label]) => (
              <Link key={to} to={to} onClick={() => setOpen(false)} className="block py-2 text-sm font-medium">{label}</Link>
            ))}
            <div className="mt-3 flex gap-2">
              {user ? <Link to={portalPath(role)} onClick={() => setOpen(false)} className="btn-primary flex-1">My Portal</Link>
                : <Link to="/login" onClick={() => setOpen(false)} className="btn-outline flex-1">Student Portal</Link>}
              <Link to="/apply" onClick={() => setOpen(false)} className="btn-gold flex-1">Apply Now</Link>
            </div>
          </div>
        )}
      </header>

      <main className="flex-1"><Outlet /></main>

      <a href={waLink()} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"
         className="no-print fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-green-500 px-4 py-3 text-sm font-semibold text-white shadow-lg hover:bg-green-600">
        <MessageCircle size={20} /> <span className="hidden sm:inline">WhatsApp</span>
      </a>

      <footer className="bg-navy-950 text-slate-300">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-4">
          <div className="md:col-span-1">
            <Logo light />
            <p className="mt-3 text-sm text-slate-400">Computer, IT and professional skills training in Chunian, Punjab.</p>
          </div>
          <div>
            <h4 className="mb-3 font-semibold text-white">Explore</h4>
            <ul className="space-y-1.5 text-sm">
              {[['/courses', 'Courses'], ['/government-programs', 'Government Programs'], ['/private-programs', 'Private Programs'], ['/physical-classes', 'Physical Classes'], ['/events', 'Events'], ['/news', 'News & Updates'], ['/careers', 'Careers'], ['/gallery', 'Gallery']].map(([to, l]) => (
                <li key={to}><Link to={to} className="hover:text-gold-400">{l}</Link></li>))}
            </ul>
          </div>
          <div>
            <h4 className="mb-3 font-semibold text-white">Students</h4>
            <ul className="space-y-1.5 text-sm">
              {[['/login', 'Student Login'], ['/teacher-login', 'Teacher Portal'], ['/admin-login', 'Admin Portal'], ['/application-status', 'Application Status'], ['/verify-certificate', 'Verify Certificate'], ['/faqs', 'FAQs'], ['/student-guidelines', 'Student Guidelines'], ['/refund-policy', 'Refund Policy'], ['/privacy-policy', 'Privacy Policy'], ['/terms', 'Terms & Conditions']].map(([to, l]) => (
                <li key={to}><Link to={to} className="hover:text-gold-400">{l}</Link></li>))}
            </ul>
          </div>
          <div>
            <h4 className="mb-3 font-semibold text-white">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex gap-2"><MapPin size={16} className="mt-0.5 shrink-0" /> {INSTITUTE.city}</li>
              <li className="flex gap-2"><Phone size={16} className="mt-0.5 shrink-0" /> <a href={`tel:${INSTITUTE.phone}`}>{INSTITUTE.phone}</a></li>
              <li className="flex gap-2"><Mail size={16} className="mt-0.5 shrink-0" /> <a href={`mailto:${INSTITUTE.email}`} className="break-all">{INSTITUTE.email}</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/10 py-4 text-center text-xs text-slate-500">
          © {new Date().getFullYear()} {INSTITUTE.name}. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
