import { Link } from 'react-router-dom'
import { isConfigured } from '../lib/supabase'
import { INSTITUTE } from '../lib/config'

export function Logo({ light = false, size = 40 }) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <img src="/logo.svg" alt="" width={size} height={size} />
      <span className={`font-display text-sm font-bold leading-tight sm:text-base ${light ? 'text-white' : 'text-navy-900 dark:text-white'}`}>
        THE SOCRATES TECH.<br /><span className="text-gold-500">CHUNIAN</span>
      </span>
    </span>
  )
}

export function Spinner({ label = 'Loading...' }) {
  return (
    <div className="flex items-center justify-center gap-3 py-16 text-slate-500">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-royal-500 border-t-transparent" />
      {label}
    </div>
  )
}

export function Empty({ title = 'Nothing here yet', text, action }) {
  return (
    <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center dark:border-white/20">
      <p className="font-semibold">{title}</p>
      {text && <p className="mt-1 text-sm text-slate-500">{text}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function ErrorBox({ message }) {
  if (!message) return null
  return <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-700 dark:bg-red-950/40 dark:text-red-300">{message}</div>
}

export function SetupNotice() {
  if (isConfigured) return null
  return (
    <div className="bg-amber-100 px-4 py-2 text-center text-xs text-amber-900">
      Setup needed: the database is not connected yet. Follow README.md (Step 2) and add your Supabase keys to the .env file.
    </div>
  )
}

export function PageHeader({ title, subtitle }) {
  return (
    <section className="bg-gradient-to-br from-navy-950 via-navy-900 to-navy-700 py-14 text-white">
      <div className="mx-auto max-w-6xl px-4">
        <h1 className="text-3xl font-bold sm:text-4xl">{title}</h1>
        {subtitle && <p className="mt-2 max-w-2xl text-slate-300">{subtitle}</p>}
      </div>
    </section>
  )
}

export function StatusBadge({ status }) {
  const map = {
    pending: 'bg-amber-100 text-amber-800', approved: 'bg-green-100 text-green-800', paid: 'bg-green-100 text-green-800',
    active: 'bg-green-100 text-green-800', rejected: 'bg-red-100 text-red-800', unpaid: 'bg-red-100 text-red-800',
    correction_requested: 'bg-blue-100 text-blue-800', completed: 'bg-blue-100 text-blue-800',
  }
  return <span className={`badge ${map[status] || 'bg-slate-100 text-slate-700'}`}>{String(status).replace('_', ' ')}</span>
}

export function Contact() {
  return (
    <ul className="space-y-1 text-sm">
      <li>{INSTITUTE.city}</li>
      <li><a href={`mailto:${INSTITUTE.email}`}>{INSTITUTE.email}</a></li>
      <li><a href={`tel:${INSTITUTE.phone}`}>{INSTITUTE.phone}</a></li>
    </ul>
  )
}

export const L = Link
