import { useMemo, useState } from 'react'
import { exportCSV } from '../lib/hooks'
import { Empty } from './ui'

// columns: [{ key, label, render?(row), sortable? }]; rows: array; exportName: enables CSV export
export default function DataTable({ columns, rows, exportName, searchKeys, empty = 'No records found', filter }) {
  const [q, setQ] = useState('')
  const [sort, setSort] = useState({ key: null, dir: 1 })

  const data = useMemo(() => {
    let r = rows || []
    if (q && searchKeys) r = r.filter((x) => searchKeys.some((k) => String(x[k] ?? '').toLowerCase().includes(q.toLowerCase())))
    if (sort.key) r = [...r].sort((a, b) => (a[sort.key] > b[sort.key] ? 1 : a[sort.key] < b[sort.key] ? -1 : 0) * sort.dir)
    return r
  }, [rows, q, sort, searchKeys])

  return (
    <div className="card overflow-x-auto !p-4">
      <div className="mb-3 flex flex-wrap items-center gap-3">
        {searchKeys && <input className="input max-w-xs" placeholder="Search..." value={q} onChange={(e) => setQ(e.target.value)} />}
        {filter}
        <span className="text-xs text-slate-500">{data.length} record(s)</span>
        {exportName && <button className="btn-outline ml-auto !py-1.5" onClick={() => exportCSV(exportName + '.csv', data.map(({ ...r }) => { Object.keys(r).forEach((k) => typeof r[k] === 'object' && r[k] !== null && delete r[k]); return r }))}>Export CSV</button>}
      </div>
      {!data.length ? <Empty title={empty} /> : (
        <table className="w-full">
          <thead><tr>{columns.map((c) => (
            <th key={c.key} className={`th ${c.sortable !== false && c.key ? 'cursor-pointer select-none' : ''}`}
              onClick={() => c.sortable !== false && c.key && setSort({ key: c.key, dir: sort.key === c.key ? -sort.dir : 1 })}>
              {c.label}{sort.key === c.key ? (sort.dir === 1 ? ' ▲' : ' ▼') : ''}</th>))}</tr></thead>
          <tbody>{data.map((r, i) => <tr key={r.id || i} className="border-t border-slate-100 dark:border-white/10">{columns.map((c) => <td key={c.key || c.label} className="td">{c.render ? c.render(r) : r[c.key]}</td>)}</tr>)}</tbody>
        </table>)}
    </div>
  )
}
