import { useState } from 'react'
import { NavLink, Outlet, Link, useNavigate } from 'react-router-dom'
import { Menu, X } from 'lucide-react'
import { Logo } from './ui'
import { useAuth } from '../lib/AuthContext'

// Shared sidebar layout for the Student, Teacher and Admin portals.
export default function PortalShell({ title, items }) {
  const [open, setOpen] = useState(false)
  const { profile, signOut } = useAuth()
  const nav = useNavigate()
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy-950 md:flex">
      <aside className={`${open ? 'block' : 'hidden'} no-print w-full shrink-0 bg-navy-900 p-4 text-slate-200 md:block md:min-h-screen md:w-64`}>
        <Link to="/"><Logo light /></Link>
        <p className="mt-5 text-xs font-semibold uppercase tracking-wider text-gold-400">{title}</p>
        <nav className="mt-2 space-y-0.5">
          {items.map(([to, label, end]) => (
            <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)}
              className={({ isActive }) => `block rounded-lg px-3 py-2 text-sm ${isActive ? 'bg-royal-600 text-white' : 'hover:bg-white/10'}`}>{label}</NavLink>
          ))}
        </nav>
        <button className="mt-6 w-full rounded-lg border border-white/20 px-3 py-2 text-sm hover:bg-white/10"
          onClick={async () => { await signOut(); nav('/') }}>Logout</button>
      </aside>
      <div className="flex-1">
        <div className="no-print flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3 dark:border-white/10 dark:bg-navy-900">
          <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">{open ? <X /> : <Menu />}</button>
          <span className="text-sm text-slate-500">Signed in as <b>{profile?.full_name || profile?.email}</b></span>
        </div>
        <div className="p-4 md:p-8"><Outlet /></div>
      </div>
    </div>
  )
}
