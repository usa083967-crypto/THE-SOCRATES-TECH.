import { Link } from 'react-router-dom'
import { Clock, Monitor } from 'lucide-react'
import { money } from '../lib/config'

const modeLabel = { physical: 'On campus', online: 'Online', both: 'On campus & online' }

export default function CourseCard({ c }) {
  return (
    <div className="card flex flex-col transition hover:-translate-y-1 hover:shadow-lg">
      <span className="badge self-start bg-royal-500/10 text-royal-600 dark:text-royal-400">{c.category}</span>
      <h3 className="mt-3 text-lg font-bold">{c.title}</h3>
      <p className="mt-1 flex-1 text-sm text-slate-600 dark:text-slate-300">{c.short_description}</p>
      <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
        {c.duration && <span className="flex items-center gap-1"><Clock size={13} /> {c.duration}</span>}
        <span className="flex items-center gap-1"><Monitor size={13} /> {modeLabel[c.mode]}</span>
      </div>
      <div className="mt-4 flex items-center justify-between">
        <span className="text-sm font-semibold">{Number(c.total_fee) > 0 ? money(c.total_fee) : 'Fee on enquiry'}</span>
        <Link to={`/courses/${c.slug}`} className="btn-primary !px-3 !py-1.5">Details</Link>
      </div>
    </div>
  )
}
