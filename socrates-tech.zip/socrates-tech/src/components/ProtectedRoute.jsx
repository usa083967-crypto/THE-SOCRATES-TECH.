import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../lib/AuthContext'
import { Spinner } from './ui'

// roles: array of allowed roles. UI protection only; real security is enforced by database policies.
export default function ProtectedRoute({ roles, children }) {
  const { user, role, loading } = useAuth()
  const loc = useLocation()
  if (loading) return <Spinner />
  if (!user) {
    const to = roles?.includes('admin') ? '/admin-login' : roles?.includes('teacher') ? '/teacher-login' : '/login'
    return <Navigate to={to} state={{ from: loc.pathname }} replace />
  }
  if (roles && !roles.includes(role)) {
    return (
      <div className="mx-auto max-w-md py-24 text-center">
        <h1 className="text-2xl font-bold">Access denied</h1>
        <p className="mt-2 text-slate-500">Your account does not have permission to view this area.</p>
      </div>
    )
  }
  return children
}
