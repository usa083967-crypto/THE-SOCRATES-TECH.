-- =====================================================================
-- THE SOCRATES TECH. CHUNIAN  -  Database schema (PostgreSQL / Supabase)
-- Run this ONCE in Supabase: SQL Editor -> New query -> paste -> Run.
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- Helper: roles ----------
create type user_role as enum ('student', 'teacher', 'admin');

-- ---------- Profiles (one row per login user) ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  phone text,
  role user_role not null default 'student',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Role helper functions (SECURITY DEFINER avoids recursive policy checks)
create or replace function public.current_role_name() returns text
language sql stable security definer set search_path = public as $$
  select role::text from public.profiles where id = auth.uid()
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin' and is_active)
$$;

create or replace function public.is_teacher() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'teacher' and is_active)
$$;

-- Every new signup becomes a STUDENT. Nobody can self-assign admin.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, email, role)
  values (new.id,
          coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', ''),
          new.email, 'student');
  return new;
end $$;

create trigger on_auth_user_created
after insert on auth.users for each row execute function public.handle_new_user();

-- Prevent users from changing their own role / active flag
create or replace function public.protect_profile_columns() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  -- auth.uid() is null when run from the Supabase SQL Editor (the site owner), so that is allowed.
  if auth.uid() is not null and not public.is_admin() then
    new.role := old.role;
    new.is_active := old.is_active;
  end if;
  return new;
end $$;

create trigger protect_profile before update on public.profiles
for each row execute function public.protect_profile_columns();

-- ---------- Courses ----------
create table public.courses (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  category text not null,                    -- e.g. 'Computer & IT', 'Professional & Technical'
  course_type text not null default 'private' check (course_type in ('private','government')),
  short_description text,
  description text,
  duration text,
  total_fee numeric(10,2) default 0,
  monthly_fee numeric(10,2) default 0,
  schedule text,
  mode text not null default 'both' check (mode in ('physical','online','both')),
  certificate_info text,
  syllabus text,
  is_active boolean not null default true,
  -- Government-only fields (shown only when is_verified = true)
  gov_program_name text,
  eligibility text,
  seats integer,
  admission_deadline date,
  is_free boolean default false,
  application_procedure text,
  is_verified boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- Teachers ----------
create table public.teachers (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles(id) on delete set null,
  full_name text not null,
  qualification text,
  bio text,
  photo_url text,
  is_active boolean not null default true,
  can_mark_attendance boolean not null default true,
  can_upload_materials boolean not null default true,
  can_enter_marks boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.course_teachers (
  course_id uuid references public.courses(id) on delete cascade,
  teacher_id uuid references public.teachers(id) on delete cascade,
  primary key (course_id, teacher_id)
);

-- ---------- Students ----------
create sequence public.student_seq start 1001;
create sequence public.application_seq start 1001;

create table public.students (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid unique references public.profiles(id) on delete set null,
  student_code text unique not null default ('STC-' || to_char(now(),'YY') || '-' || nextval('public.student_seq')),
  full_name text not null,
  father_name text,
  dob date,
  gender text,
  cnic text,
  mobile text,
  whatsapp text,
  email text,
  address text,
  city text,
  qualification text,
  photo_path text,
  status text not null default 'active' check (status in ('active','inactive','completed')),
  created_at timestamptz not null default now()
);

-- ---------- Applications (online admission) ----------
create table public.applications (
  id uuid primary key default gen_random_uuid(),
  application_code text unique not null default ('APP-' || to_char(now(),'YYYY') || '-' || nextval('public.application_seq')),
  applicant_id uuid references auth.users(id) on delete set null,
  full_name text not null,
  father_name text not null,
  dob date,
  gender text,
  cnic text not null,
  mobile text not null,
  whatsapp text,
  email text,
  address text,
  city text,
  qualification text,
  course_id uuid references public.courses(id),
  course_type text,
  learning_mode text check (learning_mode in ('physical','online')),
  photo_path text,
  cnic_doc_path text,
  education_doc_path text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','correction_requested')),
  admin_note text,
  student_id uuid references public.students(id),
  created_at timestamptz not null default now()
);

-- ---------- Enrollments ----------
create table public.enrollments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  learning_mode text default 'physical',
  status text not null default 'active' check (status in ('active','completed','dropped')),
  progress_percent integer not null default 0 check (progress_percent between 0 and 100),
  enrolled_on date not null default current_date,
  unique (student_id, course_id)
);

-- ---------- Fees ----------
create sequence public.voucher_seq start 10001;

create table public.fee_records (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  enrollment_id uuid references public.enrollments(id) on delete set null,
  fee_type text not null default 'monthly' check (fee_type in ('admission','registration','course','monthly','other')),
  fee_month text,                           -- e.g. '2026-11'
  tuition numeric(10,2) not null default 0,
  other_charges numeric(10,2) not null default 0,
  discount numeric(10,2) not null default 0,
  total_payable numeric(10,2) generated always as (greatest(tuition + other_charges - discount, 0)) stored,
  due_date date,
  status text not null default 'unpaid' check (status in ('unpaid','paid','waived')),
  voucher_no text unique not null default ('SV-' || nextval('public.voucher_seq')),
  issue_date date not null default current_date,
  created_at timestamptz not null default now()
);

-- Payments exist ONLY when an admin verifies them.
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  fee_record_id uuid not null references public.fee_records(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  amount numeric(10,2) not null,
  method text,                              -- cash, bank transfer, JazzCash, Easypaisa...
  reference_no text,
  verified_by uuid references public.profiles(id),
  paid_on date not null default current_date,
  created_at timestamptz not null default now()
);

-- ---------- Attendance ----------
create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  attendance_date date not null default current_date,
  status text not null check (status in ('present','absent','late','leave')),
  marked_by uuid references public.profiles(id),
  unique (student_id, course_id, attendance_date)
);

-- ---------- Timetable ----------
create table public.timetable (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  teacher_id uuid references public.teachers(id) on delete set null,
  day_of_week text not null,
  start_time time,
  end_time time,
  room text
);

-- ---------- LMS: modules, lessons, materials ----------
create table public.modules (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  position integer not null default 0
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.modules(id) on delete cascade,
  title text not null,
  content text,
  video_url text,
  position integer not null default 0
);

create table public.lesson_progress (
  student_id uuid references public.students(id) on delete cascade,
  lesson_id uuid references public.lessons(id) on delete cascade,
  completed_at timestamptz not null default now(),
  primary key (student_id, lesson_id)
);

create table public.materials (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  file_path text not null,
  uploaded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

-- ---------- Assignments ----------
create table public.assignments (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  description text,
  file_path text,
  due_date date,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.submissions (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.assignments(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  file_path text,
  note text,
  marks numeric(6,2),
  submitted_at timestamptz not null default now(),
  unique (assignment_id, student_id)
);

-- ---------- Quizzes ----------
create table public.quizzes (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  is_published boolean not null default false
);

create table public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  question text not null,
  options jsonb not null,                   -- ["A","B","C","D"]
  correct_index integer not null
);

create table public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  score integer not null,
  total integer not null,
  taken_at timestamptz not null default now()
);

-- ---------- Results ----------
create table public.results (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  exam_name text not null,
  marks_obtained numeric(6,2) not null,
  total_marks numeric(6,2) not null,
  grade text,
  is_published boolean not null default false,
  entered_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

-- ---------- Certificates ----------
create table public.certificates (
  id uuid primary key default gen_random_uuid(),
  certificate_no text unique not null,
  verification_id text unique not null default encode(gen_random_bytes(6), 'hex'),
  student_id uuid not null references public.students(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  student_name text not null,
  course_title text not null,
  completion_date date not null,
  issued_by uuid references public.profiles(id),
  issued_at timestamptz not null default now(),
  is_revoked boolean not null default false
);

-- ---------- Scholarships / support ----------
create table public.scholarships (
  id uuid primary key default gen_random_uuid(),
  applicant_id uuid references auth.users(id) on delete set null,
  full_name text not null,
  mobile text not null,
  email text,
  course_id uuid references public.courses(id),
  request_type text not null check (request_type in ('scholarship','fee_concession','financial_assistance','free_training')),
  reason text not null,
  family_income text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','more_info')),
  admin_note text,
  created_at timestamptz not null default now()
);

-- ---------- Notifications / announcements ----------
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,   -- null = broadcast
  title text not null,
  body text,
  category text default 'general',
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text,
  audience text not null default 'all' check (audience in ('all','students','teachers','public')),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

-- ---------- Contact / complaints ----------
create table public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  kind text not null default 'contact' check (kind in ('contact','support','complaint')),
  name text not null,
  email text,
  phone text,
  subject text,
  message text not null,
  user_id uuid references auth.users(id) on delete set null,
  status text not null default 'new' check (status in ('new','in_progress','resolved')),
  created_at timestamptz not null default now()
);

-- ---------- Website content ----------
create table public.testimonials (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  course text,
  quote text not null,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.banners (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subtitle text,
  link text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.faqs (
  id uuid primary key default gen_random_uuid(),
  question text not null,
  answer text not null,
  position integer default 0,
  is_published boolean not null default true
);

-- =====================================================================
-- ROW LEVEL SECURITY  (this is what keeps student data private)
-- =====================================================================
alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.teachers enable row level security;
alter table public.course_teachers enable row level security;
alter table public.students enable row level security;
alter table public.applications enable row level security;
alter table public.enrollments enable row level security;
alter table public.fee_records enable row level security;
alter table public.payments enable row level security;
alter table public.attendance enable row level security;
alter table public.timetable enable row level security;
alter table public.modules enable row level security;
alter table public.lessons enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.materials enable row level security;
alter table public.assignments enable row level security;
alter table public.submissions enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.results enable row level security;
alter table public.certificates enable row level security;
alter table public.scholarships enable row level security;
alter table public.notifications enable row level security;
alter table public.announcements enable row level security;
alter table public.contact_messages enable row level security;
alter table public.testimonials enable row level security;
alter table public.banners enable row level security;
alter table public.faqs enable row level security;

-- Helper: the students.id that belongs to the logged-in user
create or replace function public.my_student_id() returns uuid
language sql stable security definer set search_path = public as $$
  select id from public.students where profile_id = auth.uid()
$$;

-- Admin: full access to everything
do $$
declare t text;
begin
  for t in select unnest(array[
    'profiles','courses','teachers','course_teachers','students','applications','enrollments',
    'fee_records','payments','attendance','timetable','modules','lessons','lesson_progress',
    'materials','assignments','submissions','quizzes','quiz_questions','quiz_attempts','results',
    'certificates','scholarships','notifications','announcements','contact_messages',
    'testimonials','banners','faqs'])
  loop
    execute format('create policy "admin all %1$s" on public.%1$I for all using (public.is_admin()) with check (public.is_admin())', t);
  end loop;
end $$;

-- Profiles
create policy "own profile read" on public.profiles for select using (id = auth.uid());
create policy "own profile update" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- Public website content
create policy "public read active courses" on public.courses for select using (is_active and (course_type = 'private' or is_verified));
create policy "public read teachers" on public.teachers for select using (is_active);
create policy "public read course_teachers" on public.course_teachers for select using (true);
create policy "public read testimonials" on public.testimonials for select using (is_published);
create policy "public read banners" on public.banners for select using (is_active);
create policy "public read faqs" on public.faqs for select using (is_published);
create policy "public read announcements" on public.announcements for select using (audience in ('all','public'));

-- Contact messages: anyone may submit, nobody but admin may read
create policy "anyone submits contact" on public.contact_messages for insert with check (true);
create policy "own contact read" on public.contact_messages for select using (user_id = auth.uid());

-- Applications: anyone may apply; applicants may read their own
create policy "anyone applies" on public.applications for insert with check (status = 'pending');
create policy "own applications read" on public.applications for select using (applicant_id = auth.uid());

-- Scholarships
create policy "anyone requests support" on public.scholarships for insert with check (status = 'pending');
create policy "own scholarships read" on public.scholarships for select using (applicant_id = auth.uid());

-- Student: own records only
create policy "student own record" on public.students for select using (profile_id = auth.uid());
create policy "student own enrollments" on public.enrollments for select using (student_id = public.my_student_id());
create policy "student own fees" on public.fee_records for select using (student_id = public.my_student_id());
create policy "student own payments" on public.payments for select using (student_id = public.my_student_id());
create policy "student own attendance" on public.attendance for select using (student_id = public.my_student_id());
create policy "student own results" on public.results for select using (student_id = public.my_student_id() and is_published);
create policy "student own certificates" on public.certificates for select using (student_id = public.my_student_id());
create policy "student own submissions read" on public.submissions for select using (student_id = public.my_student_id());
create policy "student submits" on public.submissions for insert with check (student_id = public.my_student_id());
create policy "student own progress" on public.lesson_progress for all using (student_id = public.my_student_id()) with check (student_id = public.my_student_id());
create policy "student own attempts" on public.quiz_attempts for all using (student_id = public.my_student_id()) with check (student_id = public.my_student_id());

-- Course content visible only to students enrolled in that course
create policy "enrolled read timetable" on public.timetable for select using (
  exists (select 1 from public.enrollments e where e.course_id = timetable.course_id and e.student_id = public.my_student_id()));
create policy "enrolled read modules" on public.modules for select using (
  exists (select 1 from public.enrollments e where e.course_id = modules.course_id and e.student_id = public.my_student_id()));
create policy "enrolled read lessons" on public.lessons for select using (
  exists (select 1 from public.modules m join public.enrollments e on e.course_id = m.course_id
          where m.id = lessons.module_id and e.student_id = public.my_student_id()));
create policy "enrolled read materials" on public.materials for select using (
  exists (select 1 from public.enrollments e where e.course_id = materials.course_id and e.student_id = public.my_student_id()));
create policy "enrolled read assignments" on public.assignments for select using (
  exists (select 1 from public.enrollments e where e.course_id = assignments.course_id and e.student_id = public.my_student_id()));
create policy "enrolled read quizzes" on public.quizzes for select using (is_published and
  exists (select 1 from public.enrollments e where e.course_id = quizzes.course_id and e.student_id = public.my_student_id()));
create policy "enrolled read quiz questions" on public.quiz_questions for select using (
  exists (select 1 from public.quizzes q join public.enrollments e on e.course_id = q.course_id
          where q.id = quiz_questions.quiz_id and q.is_published and e.student_id = public.my_student_id()));

-- Notifications: own + broadcast; users may mark their own as read
create policy "own notifications read" on public.notifications for select using (user_id = auth.uid() or user_id is null);
create policy "own notifications update" on public.notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "read announcements signed in" on public.announcements for select using (
  auth.uid() is not null and audience in ('all','students') );

-- Teachers: only their assigned courses, and only if the admin granted the permission
create or replace function public.teacher_has_course(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.teachers t join public.course_teachers ct on ct.teacher_id = t.id
                 where t.profile_id = auth.uid() and t.is_active and ct.course_id = cid)
$$;

create policy "teacher own record" on public.teachers for select using (profile_id = auth.uid());
create policy "teacher read assigned enrollments" on public.enrollments for select using (public.teacher_has_course(course_id));
create policy "teacher read assigned students" on public.students for select using (
  exists (select 1 from public.enrollments e where e.student_id = students.id and public.teacher_has_course(e.course_id)));
create policy "teacher read attendance" on public.attendance for select using (public.teacher_has_course(course_id));
create policy "teacher mark attendance" on public.attendance for insert with check (
  public.teacher_has_course(course_id) and exists (select 1 from public.teachers t where t.profile_id = auth.uid() and t.can_mark_attendance));
create policy "teacher update attendance" on public.attendance for update using (
  public.teacher_has_course(course_id) and exists (select 1 from public.teachers t where t.profile_id = auth.uid() and t.can_mark_attendance));
create policy "teacher read materials" on public.materials for select using (public.teacher_has_course(course_id));
create policy "teacher add materials" on public.materials for insert with check (
  public.teacher_has_course(course_id) and exists (select 1 from public.teachers t where t.profile_id = auth.uid() and t.can_upload_materials));
create policy "teacher read assignments" on public.assignments for select using (public.teacher_has_course(course_id));
create policy "teacher add assignments" on public.assignments for insert with check (
  public.teacher_has_course(course_id) and exists (select 1 from public.teachers t where t.profile_id = auth.uid() and t.can_upload_materials));
create policy "teacher read timetable" on public.timetable for select using (public.teacher_has_course(course_id));
create policy "teacher read submissions" on public.submissions for select using (
  exists (select 1 from public.assignments a where a.id = submissions.assignment_id and public.teacher_has_course(a.course_id)));
create policy "teacher grade submissions" on public.submissions for update using (
  exists (select 1 from public.assignments a where a.id = submissions.assignment_id and public.teacher_has_course(a.course_id)));
create policy "teacher read results" on public.results for select using (public.teacher_has_course(course_id));
create policy "teacher enter results" on public.results for insert with check (
  public.teacher_has_course(course_id) and exists (select 1 from public.teachers t where t.profile_id = auth.uid() and t.can_enter_marks));

-- Certificate verification: a SAFE public function (no table-wide public read)
create or replace function public.verify_certificate(code text)
returns table (certificate_no text, student_name text, course_title text, completion_date date, is_revoked boolean)
language sql stable security definer set search_path = public as $$
  select c.certificate_no, c.student_name, c.course_title, c.completion_date, c.is_revoked
  from public.certificates c where c.verification_id = lower(trim(code)) or c.certificate_no = trim(code)
$$;
grant execute on function public.verify_certificate(text) to anon, authenticated;

-- Application status lookup by application code + CNIC (for people without an account)
create or replace function public.check_application(code text, cnic_no text)
returns table (application_code text, full_name text, status text, admin_note text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select a.application_code, a.full_name, a.status, a.admin_note, a.created_at
  from public.applications a
  where a.application_code = trim(code) and a.cnic = trim(cnic_no)
$$;
grant execute on function public.check_application(text, text) to anon, authenticated;

-- =====================================================================
-- STORAGE BUCKETS  (private; documents are never public)
-- =====================================================================
insert into storage.buckets (id, name, public) values
  ('applications', 'applications', false),
  ('materials', 'materials', false),
  ('submissions', 'submissions', false)
on conflict (id) do nothing;

-- Anyone may upload an admission document, but only into the applications bucket, never read it
create policy "upload application docs" on storage.objects for insert to anon, authenticated
  with check (bucket_id = 'applications');
create policy "admin read application docs" on storage.objects for select
  using (bucket_id = 'applications' and public.is_admin());
create policy "admin manage all storage" on storage.objects for all
  using (public.is_admin()) with check (public.is_admin());

-- Enrolled students and teachers read course materials
create policy "signed-in read materials" on storage.objects for select to authenticated
  using (bucket_id = 'materials');
create policy "teacher upload materials" on storage.objects for insert to authenticated
  with check (bucket_id = 'materials' and (public.is_teacher() or public.is_admin()));

-- Students upload submissions into a folder named after their user id
create policy "student upload submission" on storage.objects for insert to authenticated
  with check (bucket_id = 'submissions' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "student read own submission" on storage.objects for select to authenticated
  using (bucket_id = 'submissions' and (storage.foldername(name))[1] = auth.uid()::text);

-- =====================================================================
-- MAKE YOURSELF ADMIN (run AFTER you sign up on the website once):
--   update public.profiles set role = 'admin' where email = 'YOUR-EMAIL@gmail.com';
-- =====================================================================

-- =====================================================================
-- Submit an application and get back its unique application code.
-- (Needed because visitors who are not logged in cannot read the table.)
-- =====================================================================
create or replace function public.submit_application(p jsonb)
returns text
language plpgsql security definer set search_path = public as $$
declare code text;
begin
  insert into public.applications (
    applicant_id, full_name, father_name, dob, gender, cnic, mobile, whatsapp, email, address, city,
    qualification, course_id, course_type, learning_mode, photo_path, cnic_doc_path, education_doc_path)
  values (
    auth.uid(), p->>'full_name', p->>'father_name', nullif(p->>'dob','')::date, p->>'gender', p->>'cnic',
    p->>'mobile', p->>'whatsapp', p->>'email', p->>'address', p->>'city', p->>'qualification',
    nullif(p->>'course_id','')::uuid, p->>'course_type', p->>'learning_mode',
    p->>'photo_path', p->>'cnic_doc_path', p->>'education_doc_path')
  returning application_code into code;

  insert into public.notifications (user_id, title, body, category)
  select auth.uid(), 'Application received',
         'Your application ' || code || ' has been received and is pending review.', 'admission'
  where auth.uid() is not null;
  return code;
end $$;
grant execute on function public.submit_application(jsonb) to anon, authenticated;
